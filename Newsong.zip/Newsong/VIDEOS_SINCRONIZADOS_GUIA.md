# 🎥 SINCRONIZAÇÃO DE VÍDEOS - GUIA DE ATIVAÇÃO

## ✅ O que foi implementado:

1. **Tabela `videos` no Supabase** - Armazena vídeos na nuvem
2. **Políticas RLS** - Segurança para que professores gerenciem seus vídeos
3. **Upload automático** - Salva no Supabase e localStorage
4. **Carregamento multi-PC** - Vídeos aparecem em qualquer computador

## 📋 Passos para ativar:

### 1. Execute no SQL Editor do Supabase:

Abra: https://supabase.com/dashboard/project/wbzaktlcxgmctocgtifj/sql/new

Cole e execute o conteúdo de: `database/15-setup-videos-sync.sql`

### 2. Teste o sistema:

1. **Faça login como professor** no PC 1
2. **Envie um vídeo** (Link do YouTube)
3. **Faça login em outro PC** com a mesma conta
4. **Verifique se o vídeo aparece** em "Meus Vídeos"

## 🔍 Como funciona:

### Ao fazer UPLOAD:
- ✅ Salva no Supabase (nuvem)
- ✅ Salva no localStorage/IndexedDB (backup local)
- ✅ Retorna ID do Supabase

### Ao CARREGAR vídeos:
- ✅ Busca do Supabase primeiro
- ✅ Mescla com vídeos locais (se houver)
- ✅ Mostra todos os vídeos disponíveis

### Ao TROCAR DE PC:
- ✅ Login carrega vídeos da nuvem
- ✅ Professor vê todos seus vídeos
- ✅ Alunos veem vídeos de todos professores

## 📊 Dados sincronizados:

- ✅ Título e descrição
- ✅ URL do YouTube
- ✅ Thumbnail
- ✅ Instrumento e módulo
- ✅ Nome do professor
- ✅ Views e Likes
- ✅ Data de publicação

## 🛠️ Comandos úteis (Console):

```javascript
// Salvar vídeo manualmente
await window.SupabaseVideos.saveVideo({
  title: "Teste",
  description: "Descrição",
  url: "https://youtube.com/watch?v=xxxxx",
  instrument: "guitarra",
  module: "iniciante",
  uploadType: "youtube"
})

// Carregar vídeos
await window.SupabaseVideos.loadVideos()

// Carregar apenas de um professor
await window.SupabaseVideos.loadTeacherVideos(email)

// Ver dados brutos no Supabase
// (Execute no SQL Editor)
SELECT 
  v.id,
  v.title,
  v.instrument,
  v.module,
  v.uploaded_by_name,
  v.teacher_email,
  v.views,
  v.likes,
  v.created_at
FROM videos v
ORDER BY v.created_at DESC;
```

## ⚠️ Importante:

- Vídeos do YouTube são salvos apenas a URL
- Vídeos de arquivo (upload direto) continuam no IndexedDB local
- Recomendado: usar sempre YouTube para compatibilidade total
- Dados locais não são perdidos - são backup

## 🎉 Resultado:

Agora os vídeos funcionam em **qualquer PC**, assim como login e progresso!

## 📝 Arquivos modificados:

- `database/15-setup-videos-sync.sql` (NOVO)
- `public/js/supabase-videos.js` (ATUALIZADO)
- `public/js/upload.js` (ATUALIZADO)

## 🚀 Próximos passos:

Depois de ativar, você precisa também carregar os vídeos do Supabase nas páginas:
- `app.html` - Página principal
- `videos.html` - Lista de vídeos
- `stats.html` - Estatísticas do professor

Isso será feito automaticamente quando você recarregar as páginas após fazer o upload!
