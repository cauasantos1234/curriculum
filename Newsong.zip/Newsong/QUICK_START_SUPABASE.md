# ⚡ QUICK START - INTEGRAÇÃO SUPABASE

## 🚀 COMEÇAR A USAR EM 3 PASSOS

### PASSO 1: Verificar se está funcionando

Abra o site e pressione **F12** para abrir o Console. Cole este código:

```javascript
// Verificar se os módulos foram carregados
console.log('✅ Módulos disponíveis:');
console.log('- SupabaseAuth:', !!window.SupabaseAuth);
console.log('- SupabaseVideos:', !!window.SupabaseVideos);  
console.log('- SupabaseProgress:', !!window.SupabaseProgress);
console.log('- SupabaseXP:', !!window.SupabaseXP);

// Verificar conexão com Supabase
const client = window.SupabaseAPI.getClient();
console.log('- Supabase Client:', !!client);
```

**Resultado esperado:**
```
✅ Módulos disponíveis:
- SupabaseAuth: true
- SupabaseVideos: true
- SupabaseProgress: true
- SupabaseXP: true
- Supabase Client: true
```

---

### PASSO 2: Testar salvamento de vídeo

No console (F12), cole:

```javascript
// Teste: Salvar vídeo
(async () => {
  const resultado = await window.SupabaseVideos.saveVideo({
    title: 'Vídeo de Teste',
    description: 'Descrição de teste',
    url: 'https://youtube.com/watch?v=dQw4w9WgXcQ',
    thumbnail: '🎸',
    instrument: 'guitar',
    module: 'beginner',
    lessonId: 101,
    lessonTitle: 'Teste de Integração',
    duration: '5:00'
  });
  
  if (resultado.success) {
    console.log('✅ SUCESSO! Vídeo salvo:', resultado.data);
  } else {
    console.error('❌ ERRO:', resultado.error);
  }
})();
```

**Verificar no Supabase:**
1. Vá em https://supabase.com
2. Entre no seu projeto
3. Vá em **Table Editor** → **videos**
4. Veja se o vídeo foi salvo

---

### PASSO 3: Testar carregamento de vídeos

No console (F12), cole:

```javascript
// Teste: Carregar vídeos
(async () => {
  const resultado = await window.SupabaseVideos.loadVideos({
    instrument: 'guitar',
    module: 'beginner'
  });
  
  if (resultado.success) {
    console.log(`✅ SUCESSO! ${resultado.data.length} vídeos carregados`);
    console.table(resultado.data);
  } else {
    console.error('❌ ERRO:', resultado.error);
  }
})();
```

---

## 🎯 INTEGRAR NO CÓDIGO

### 1. Upload de Vídeos (`upload.js`)

**Encontre a função que salva o vídeo e adicione:**

```javascript
// ANTES (só localStorage)
function salvarVideo(videoData) {
  const videos = JSON.parse(localStorage.getItem('ns-videos') || '[]');
  videos.push(videoData);
  localStorage.setItem('ns-videos', JSON.stringify(videos));
}

// DEPOIS (localStorage + Supabase)
async function salvarVideo(videoData) {
  // Salvar localmente como backup
  const videos = JSON.parse(localStorage.getItem('ns-videos') || '[]');
  videos.push(videoData);
  localStorage.setItem('ns-videos', JSON.stringify(videos));
  
  // Salvar no Supabase
  if (window.SupabaseVideos) {
    const result = await window.SupabaseVideos.saveVideo(videoData);
    
    if (result.success) {
      console.log('✅ Vídeo salvo no Supabase!');
      showNotification('Sucesso!', 'Vídeo postado e sincronizado com a nuvem');
    } else {
      console.error('❌ Erro ao salvar no Supabase:', result.error);
      showNotification('Aviso', 'Vídeo salvo localmente, mas não foi possível sincronizar');
    }
  }
}
```

---

### 2. Listagem de Vídeos (`videos.js`)

**Encontre a função que carrega os vídeos e adicione:**

```javascript
// ANTES (só localStorage)
function carregarVideos() {
  const videos = JSON.parse(localStorage.getItem('ns-videos') || '[]');
  renderizarVideos(videos);
}

// DEPOIS (Supabase primeiro, depois localStorage)
async function carregarVideos(filtros = {}) {
  // Tentar carregar do Supabase primeiro
  if (window.SupabaseVideos) {
    const result = await window.SupabaseVideos.loadVideos(filtros);
    
    if (result.success && result.data.length > 0) {
      console.log(`✅ ${result.data.length} vídeos carregados do Supabase`);
      renderizarVideos(result.data);
      return;
    }
  }
  
  // Fallback para localStorage
  console.log('⚠️ Usando dados locais');
  const videos = JSON.parse(localStorage.getItem('ns-videos') || '[]');
  renderizarVideos(videos);
}
```

---

### 3. Sistema de XP (`xp-system.js`)

**Quando o usuário ganhar XP, adicione:**

```javascript
// ANTES (só localStorage)
function ganharXP(quantidade) {
  const xp = JSON.parse(localStorage.getItem('user-xp') || '{"total": 0}');
  xp.total += quantidade;
  localStorage.setItem('user-xp', JSON.stringify(xp));
  atualizarUI(xp);
}

// DEPOIS (localStorage + Supabase)
async function ganharXP(quantidade, motivo = '') {
  // Salvar localmente
  const xp = JSON.parse(localStorage.getItem('user-xp') || '{"total": 0}');
  xp.total += quantidade;
  localStorage.setItem('user-xp', JSON.stringify(xp));
  
  // Salvar no Supabase
  if (window.SupabaseXP) {
    const result = await window.SupabaseXP.addXP(quantidade, motivo);
    
    if (result.success) {
      console.log(`✅ +${result.data.xpAdded} XP! Nível: ${result.data.level}`);
      atualizarUI(result.data);
    }
  } else {
    atualizarUI(xp);
  }
}
```

---

### 4. Progresso do Usuário (`user-progress.js`)

**Ao salvar progresso, adicione:**

```javascript
// ANTES (só localStorage)
function salvarProgresso(progresso) {
  const chave = `progresso-${usuario.email}`;
  localStorage.setItem(chave, JSON.stringify(progresso));
}

// DEPOIS (localStorage + Supabase)
async function salvarProgresso(progresso) {
  // Salvar localmente
  const chave = `progresso-${usuario.email}`;
  localStorage.setItem(chave, JSON.stringify(progresso));
  
  // Salvar no Supabase
  if (window.SupabaseProgress) {
    const result = await window.SupabaseProgress.saveProgress(progresso);
    
    if (result.success) {
      console.log('✅ Progresso sincronizado com a nuvem');
    }
  }
}
```

---

## 🎮 COMANDOS ÚTEIS NO CONSOLE

### Verificar usuário logado
```javascript
const session = JSON.parse(localStorage.getItem('ns-session') || '{}');
console.log('Usuário:', session);
```

### Carregar XP do usuário
```javascript
const xp = await window.SupabaseXP.loadUserXP();
console.log('XP:', xp.data);
```

### Carregar ranking
```javascript
const ranking = await window.SupabaseXP.loadRanking(10);
console.log('Top 10:', ranking.data);
```

### Carregar progresso
```javascript
const progresso = await window.SupabaseProgress.loadProgress();
console.log('Progresso:', progresso.data);
```

### Salvar vídeo nos favoritos
```javascript
await window.SupabaseVideos.saveVideoToFavorites(123); // ID do vídeo
```

### Incrementar views
```javascript
await window.SupabaseVideos.incrementViews(123); // ID do vídeo
```

---

## 📊 VER DADOS NO SUPABASE

1. Acesse: https://supabase.com
2. Entre no projeto `newsong`
3. Vá em **Table Editor**
4. Clique na tabela que quer ver:
   - `users` → Usuários cadastrados
   - `videos` → Vídeos postados
   - `user_xp` → XP e nível dos usuários
   - `user_progress` → Progresso individual
   - `saved_videos` → Vídeos salvos
   - `video_views` → Histórico de visualizações

---

## ✅ VANTAGENS DO SISTEMA

### Sistema Híbrido
- ✅ Funciona **offline** (localStorage)
- ✅ Sincroniza quando **online** (Supabase)
- ✅ **Não perde dados** se limpar navegador
- ✅ **Multi-dispositivo** (mesmo progresso em todos)

### Exemplo Real
```
Usuário faz login no PC → Assiste 5 aulas → Ganha 500 XP
↓
Dados salvos no Supabase
↓
Usuário faz login no celular → Vê as 5 aulas concluídas → Tem os mesmos 500 XP
```

---

## 🆘 PROBLEMAS?

### Módulo não carregado
```javascript
// Verificar se o script foi incluído
console.log('Scripts carregados:', document.querySelectorAll('script[src*="supabase"]'));
```

### Erro "User not authenticated"
```javascript
// Verificar se está logado
const session = localStorage.getItem('ns-session');
if (!session) {
  console.log('❌ Usuário não está logado!');
  // Fazer login primeiro
}
```

### Dados não salvam no Supabase
1. Abra o Console (F12)
2. Procure por erros em vermelho
3. Verifique se o Supabase está configurado
4. Teste a conexão: `console.log(window.SupabaseAPI.getClient())`

---

**Pronto para usar!** 🎉

Comece testando no console e depois integre no código conforme os exemplos acima.
