-- ============================================
-- PERMITIR ACESSO AOS USUÁRIOS
-- Execute este script no SQL Editor do Supabase
-- ============================================

-- 1. Habilitar RLS na tabela users (se ainda não estiver)
ALTER TABLE IF EXISTS users ENABLE ROW LEVEL SECURITY;

-- 2. Criar política para permitir leitura de todos os usuários
DROP POLICY IF EXISTS "Allow read users" ON users;
CREATE POLICY "Allow read users" ON users 
  FOR SELECT 
  USING (true);

-- 3. Criar política para permitir inserção (para registros)
DROP POLICY IF EXISTS "Allow insert users" ON users;
CREATE POLICY "Allow insert users" ON users 
  FOR INSERT 
  WITH CHECK (true);

-- 4. Criar política para permitir atualização (próprio usuário)
DROP POLICY IF EXISTS "Allow update own user" ON users;
CREATE POLICY "Allow update own user" ON users 
  FOR UPDATE 
  USING (auth.uid() = id);

-- 5. Criar função para buscar usuários do Auth
CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz,
  last_sign_in_at timestamptz,
  role text,
  email_confirmed_at timestamptz
) 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY 
  SELECT 
    au.id,
    au.email::text,
    au.created_at,
    au.last_sign_in_at,
    COALESCE(au.raw_user_meta_data->>'role', 'student')::text as role,
    au.email_confirmed_at
  FROM auth.users au
  ORDER BY au.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- 6. Verificar se há usuários
SELECT 'Total de usuários no Auth:' as info, COUNT(*) as total FROM auth.users;
SELECT 'Total de usuários na tabela users:' as info, COUNT(*) as total FROM users;

-- 7. Listar usuários do Auth
SELECT 
  id,
  email,
  created_at,
  last_sign_in_at,
  email_confirmed_at,
  raw_user_meta_data
FROM auth.users
ORDER BY created_at DESC;
