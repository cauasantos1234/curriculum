-- ============================================
-- CONFIGURAR SINCRONIZAÇÃO DE VÍDEOS
-- Execute este script no SQL Editor do Supabase
-- ============================================

-- 1. Verificar se a tabela videos existe, se não criar
CREATE TABLE IF NOT EXISTS videos (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  url TEXT,  -- URL do YouTube
  thumbnail_url TEXT,
  instrument VARCHAR(50),
  module VARCHAR(50), -- 'beginner', 'intermediate', 'advanced'
  lesson VARCHAR(255),
  duration VARCHAR(20),
  
  -- Autor
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  uploaded_by_name VARCHAR(255),
  teacher_email VARCHAR(255),
  
  -- Estatísticas
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  
  -- Metadados
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  is_published BOOLEAN DEFAULT true,
  upload_type VARCHAR(20) DEFAULT 'youtube'
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_videos_uploaded_by ON videos(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_videos_teacher_email ON videos(teacher_email);
CREATE INDEX IF NOT EXISTS idx_videos_instrument ON videos(instrument);
CREATE INDEX IF NOT EXISTS idx_videos_module ON videos(module);
CREATE INDEX IF NOT EXISTS idx_videos_created ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(is_published);

-- 2. Habilitar RLS
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- 3. Políticas de segurança

-- Todos podem ler vídeos publicados
DROP POLICY IF EXISTS "Anyone can read published videos" ON videos;
CREATE POLICY "Anyone can read published videos" 
  ON videos 
  FOR SELECT 
  USING (is_published = true);

-- Usuários autenticados podem inserir vídeos
DROP POLICY IF EXISTS "Authenticated users can insert videos" ON videos;
CREATE POLICY "Authenticated users can insert videos" 
  ON videos 
  FOR INSERT 
  WITH CHECK (auth.uid() = uploaded_by);

-- Usuários podem atualizar seus próprios vídeos
DROP POLICY IF EXISTS "Users can update own videos" ON videos;
CREATE POLICY "Users can update own videos" 
  ON videos 
  FOR UPDATE 
  USING (auth.uid() = uploaded_by);

-- Usuários podem deletar seus próprios vídeos
DROP POLICY IF EXISTS "Users can delete own videos" ON videos;
CREATE POLICY "Users can delete own videos" 
  ON videos 
  FOR DELETE 
  USING (auth.uid() = uploaded_by);

-- 4. Função para atualizar timestamp automaticamente
CREATE OR REPLACE FUNCTION update_videos_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_videos_timestamp ON videos;
CREATE TRIGGER trigger_update_videos_timestamp
  BEFORE UPDATE ON videos
  FOR EACH ROW
  EXECUTE FUNCTION update_videos_timestamp();

-- 5. Ver estrutura da tabela
SELECT 
  column_name, 
  data_type, 
  is_nullable
FROM information_schema.columns
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- 6. Testar
SELECT 'Setup de videos concluído! ✅' as status;
