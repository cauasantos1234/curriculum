-- ============================================
-- VERIFICAR VÍDEOS NO SUPABASE
-- Execute este script no SQL Editor do Supabase
-- ============================================

-- 1. Contar total de vídeos
SELECT COUNT(*) as "Total de vídeos" FROM videos;

-- 2. Listar todos os vídeos
SELECT 
  id,
  title,
  description,
  instrument,
  module,
  lesson,
  duration,
  uploaded_by_name,
  teacher_email,
  views,
  likes,
  created_at,
  url
FROM videos
ORDER BY created_at DESC;

-- 3. Verificar se a tabela existe
SELECT 
  table_name,
  column_name,
  data_type
FROM information_schema.columns
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- 4. Ver vídeos por professor
SELECT 
  teacher_email,
  COUNT(*) as total_videos,
  MAX(created_at) as ultimo_upload
FROM videos
GROUP BY teacher_email
ORDER BY total_videos DESC;
