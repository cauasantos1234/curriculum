-- =============================================================================
-- CRIAR VIEWS DE RANKING - NewSong Platform
-- =============================================================================
-- Este arquivo cria as views necessárias para o sistema de ranking
-- Versão: 1.0.0
-- Data: 15/01/2026

-- =============================================================================
-- 1. VIEW: ranking_by_xp
-- Descrição: Rankings dos usuários ordenados por XP total
-- =============================================================================

CREATE OR REPLACE VIEW public.ranking_by_xp AS
SELECT 
  u.id,
  u.name,
  u.email,
  COALESCE(ux.total_xp, 0) as total_xp,
  COALESCE(ux.current_level, 1) as current_level,
  COALESCE(ux.current_streak, 0) as current_streak,
  COALESCE(ux.longest_streak, 0) as longest_streak,
  ux.last_xp_date,
  u.created_at,
  -- Calcular posição no ranking
  RANK() OVER (ORDER BY COALESCE(ux.total_xp, 0) DESC) as rank
FROM users u
LEFT JOIN user_xp ux ON u.id = ux.user_id
ORDER BY total_xp DESC, u.created_at ASC;

-- =============================================================================
-- 2. VIEW: ranking_by_streak
-- Descrição: Rankings dos usuários ordenados por streak atual
-- =============================================================================

CREATE OR REPLACE VIEW public.ranking_by_streak AS
SELECT 
  u.id,
  u.name,
  u.email,
  COALESCE(ux.current_streak, 0) as current_streak,
  COALESCE(ux.longest_streak, 0) as longest_streak,
  COALESCE(ux.total_xp, 0) as total_xp,
  COALESCE(ux.current_level, 1) as current_level,
  ux.last_xp_date,
  u.created_at,
  -- Calcular posição no ranking
  RANK() OVER (ORDER BY COALESCE(ux.current_streak, 0) DESC) as rank
FROM users u
LEFT JOIN user_xp ux ON u.id = ux.user_id
ORDER BY current_streak DESC, longest_streak DESC, u.created_at ASC;

-- =============================================================================
-- 3. VIEW: ranking_by_level
-- Descrição: Rankings dos usuários ordenados por nível
-- =============================================================================

CREATE OR REPLACE VIEW public.ranking_by_level AS
SELECT 
  u.id,
  u.name,
  u.email,
  COALESCE(ux.current_level, 1) as current_level,
  COALESCE(ux.total_xp, 0) as total_xp,
  COALESCE(ux.current_streak, 0) as current_streak,
  COALESCE(ux.longest_streak, 0) as longest_streak,
  ux.last_xp_date,
  u.created_at,
  -- Calcular posição no ranking
  RANK() OVER (ORDER BY COALESCE(ux.current_level, 1) DESC, COALESCE(ux.total_xp, 0) DESC) as rank
FROM users u
LEFT JOIN user_xp ux ON u.id = ux.user_id
ORDER BY current_level DESC, total_xp DESC, u.created_at ASC;

-- =============================================================================
-- 4. VERIFICAÇÃO
-- =============================================================================

-- Testar as views
DO $$
BEGIN
  -- Testar ranking_by_xp
  IF EXISTS (SELECT 1 FROM information_schema.views WHERE table_name = 'ranking_by_xp') THEN
    RAISE NOTICE '✅ View ranking_by_xp criada com sucesso';
  ELSE
    RAISE EXCEPTION '❌ Falha ao criar view ranking_by_xp';
  END IF;

  -- Testar ranking_by_streak
  IF EXISTS (SELECT 1 FROM information_schema.views WHERE table_name = 'ranking_by_streak') THEN
    RAISE NOTICE '✅ View ranking_by_streak criada com sucesso';
  ELSE
    RAISE EXCEPTION '❌ Falha ao criar view ranking_by_streak';
  END IF;

  -- Testar ranking_by_level
  IF EXISTS (SELECT 1 FROM information_schema.views WHERE table_name = 'ranking_by_level') THEN
    RAISE NOTICE '✅ View ranking_by_level criada com sucesso';
  ELSE
    RAISE EXCEPTION '❌ Falha ao criar view ranking_by_level';
  END IF;

  RAISE NOTICE '✅ Todas as views de ranking foram criadas com sucesso!';
END $$;

-- =============================================================================
-- FIM DO ARQUIVO
-- =============================================================================
