// supabase-config.js - Configuração do Supabase

const SUPABASE_CONFIG = {
  url: 'https://wbzaktlcxgmctocgtifj.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiemFrdGxjeGdtY3RvY2d0aWZqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3NjEzNTEsImV4cCI6MjA4MTMzNzM1MX0.i3I01z8CT1l6kBPhNwk8bgRwJP4Jq5MO3Rn2dEsoJSM'
};

let supabaseClient = null;

function initSupabase() {
  if (supabaseClient) return true;
  
  // Verificar se a biblioteca Supabase foi carregada
  if (typeof window.supabase !== 'undefined' && typeof window.supabase.createClient === 'function') {
    try {
      supabaseClient = window.supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
      console.log('✅ Supabase inicializado com sucesso');
      return true;
    } catch (error) {
      console.error('❌ Erro ao inicializar Supabase:', error);
      return false;
    }
  }
  console.warn('⚠️ Biblioteca Supabase não carregada ainda');
  return false;
}

if (!initSupabase()) setTimeout(initSupabase, 500);

window.SupabaseAPI = {
  getClient: function() {
    if (!supabaseClient) initSupabase();
    return supabaseClient;
  },
  getConfig: function() {
    return SUPABASE_CONFIG;
  },
  isReady: function() {
    return supabaseClient !== null;
  }
};

Object.defineProperty(window, 'supabase', {
  get: function() {
    const client = window.SupabaseAPI.getClient();
    // Retornar null se não estiver pronto ao invés de undefined
    return client || null;
  }
});

window.supabaseClient = null;
setTimeout(() => {
  window.supabaseClient = window.SupabaseAPI.getClient();
}, 1000);
