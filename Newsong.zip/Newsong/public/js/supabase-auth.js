// supabase-auth.js - Integração de autenticação com Supabase
// Este arquivo funciona em conjunto com auth.js

(function() {
  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // Sincronizar usuário do localStorage com Supabase
  async function syncUserToSupabase(userData) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      // Verificar se o usuário já existe no Supabase
      const { data: existingUser, error: fetchError } = await supabase
        .from('users')
        .select('*')
        .eq('email', userData.email)
        .single();

      if (existingUser) {
        console.log('✅ Usuário já existe no Supabase');
        return existingUser;
      }

      // Se não existe, criar
      const { data: newUser, error: insertError } = await supabase
        .from('users')
        .insert([{
          email: userData.email,
          name: userData.name || userData.email.split('@')[0],
          role: userData.role || 'student',
          is_active: true
        }])
        .select()
        .single();

      if (insertError) {
        console.error('Erro ao criar usuário no Supabase:', insertError);
        return null;
      }

      console.log('✅ Usuário criado no Supabase:', newUser);
      return newUser;
    } catch (error) {
      console.error('Erro ao sincronizar usuário:', error);
      return null;
    }
  }

  // Carregar dados do usuário do Supabase
  async function loadUserFromSupabase(email) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      const { data: user, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .single();

      if (error) {
        console.log('Usuário não encontrado no Supabase');
        return null;
      }

      return user;
    } catch (error) {
      console.error('Erro ao carregar usuário:', error);
      return null;
    }
  }

  // Atualizar último login
  async function updateLastLogin(email) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      const { error } = await supabase
        .from('users')
        .update({ last_login: new Date().toISOString() })
        .eq('email', email);

      if (error) {
        console.error('Erro ao atualizar último login:', error);
      }
    } catch (error) {
      console.error('Erro ao atualizar último login:', error);
    }
  }

  // Expor funções globalmente
  window.SupabaseAuth = {
    syncUserToSupabase,
    loadUserFromSupabase,
    updateLastLogin
  };

  console.log('✅ SupabaseAuth module loaded');
})();
