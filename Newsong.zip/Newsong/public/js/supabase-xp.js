// supabase-xp.js - Integração de XP e Ranking com Supabase
// Este arquivo funciona em conjunto com xp-system.js e ranking-system.js

(function() {
  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // Adicionar XP ao usuário
  async function addXP(amount, reason = '') {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado' };
      }

      // Buscar XP atual
      const { data: xpData } = await supabase
        .from('user_xp')
        .select('*')
        .eq('user_id', user.id)
        .single();

      const currentXP = xpData ? xpData.total_xp : 0;
      const newXP = currentXP + amount;

      // Calcular nível baseado no XP
      const level = Math.floor(newXP / 1000) + 1;

      if (xpData) {
        // Atualizar XP existente
        await supabase
          .from('user_xp')
          .update({
            total_xp: newXP,
            level: level,
            updated_at: new Date().toISOString()
          })
          .eq('user_id', user.id);
      } else {
        // Criar novo registro de XP
        await supabase
          .from('user_xp')
          .insert([{
            user_id: user.id,
            total_xp: newXP,
            level: level
          }]);
      }

      // Registrar histórico de XP
      await supabase
        .from('xp_history')
        .insert([{
          user_id: user.id,
          amount: amount,
          reason: reason || 'XP ganho',
          total_after: newXP
        }]);

      console.log(`✅ +${amount} XP adicionado (Total: ${newXP}, Nível: ${level})`);
      
      // Sincronizar com localStorage
      const localXP = JSON.parse(localStorage.getItem(`newsong-xp-${session.email}`) || '{}');
      localXP.totalXP = newXP;
      localXP.level = level;
      localStorage.setItem(`newsong-xp-${session.email}`, JSON.stringify(localXP));

      return { 
        success: true, 
        data: { 
          totalXP: newXP, 
          level: level,
          xpAdded: amount 
        } 
      };
    } catch (error) {
      console.error('Erro ao adicionar XP:', error);
      return { success: false, error: error.message };
    }
  }

  // Carregar XP do usuário
  async function loadUserXP() {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado', data: null };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id, name')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado', data: null };
      }

      // Carregar XP
      const { data: xpData, error } = await supabase
        .from('user_xp')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error || !xpData) {
        console.log('XP não encontrado, criando novo registro');
        return { 
          success: true, 
          data: { 
            totalXP: 0, 
            level: 1,
            userName: user.name 
          } 
        };
      }

      const userData = {
        totalXP: xpData.total_xp || 0,
        level: xpData.level || 1,
        userName: user.name
      };

      console.log('✅ XP carregado do Supabase:', userData);
      
      // Sincronizar com localStorage
      localStorage.setItem(`newsong-xp-${session.email}`, JSON.stringify(userData));

      return { success: true, data: userData };
    } catch (error) {
      console.error('Erro ao carregar XP:', error);
      return { success: false, error: error.message, data: null };
    }
  }

  // Carregar ranking global
  async function loadRanking(limit = 10) {
    try {
      const supabase = window.SupabaseAPI.getClient();

      // Carregar top usuários por XP
      const { data: rankingData, error } = await supabase
        .from('user_xp')
        .select(`
          total_xp,
          level,
          users (
            name,
            email
          )
        `)
        .order('total_xp', { ascending: false })
        .limit(limit);

      if (error) {
        console.error('Erro ao carregar ranking:', error);
        return { success: false, error: error.message, data: [] };
      }

      // Formatar dados do ranking
      const ranking = rankingData.map((item, index) => ({
        position: index + 1,
        name: item.users.name,
        email: item.users.email,
        totalXP: item.total_xp,
        level: item.level
      }));

      console.log(`✅ Ranking carregado: ${ranking.length} usuários`);
      
      // Sincronizar com localStorage
      localStorage.setItem('newsong-ranking', JSON.stringify(ranking));

      return { success: true, data: ranking };
    } catch (error) {
      console.error('Erro ao carregar ranking:', error);
      return { success: false, error: error.message, data: [] };
    }
  }

  // Carregar histórico de XP do usuário
  async function loadXPHistory() {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado', data: [] };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado', data: [] };
      }

      // Carregar histórico
      const { data: history, error } = await supabase
        .from('xp_history')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Erro ao carregar histórico de XP:', error);
        return { success: false, error: error.message, data: [] };
      }

      console.log(`✅ ${history.length} registros de XP carregados`);
      return { success: true, data: history };
    } catch (error) {
      console.error('Erro ao carregar histórico de XP:', error);
      return { success: false, error: error.message, data: [] };
    }
  }

  // Expor funções globalmente
  window.SupabaseXP = {
    addXP,
    loadUserXP,
    loadRanking,
    loadXPHistory
  };

  console.log('✅ SupabaseXP module loaded');
})();
