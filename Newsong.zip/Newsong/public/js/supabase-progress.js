// supabase-progress.js - Integração de progresso do usuário com Supabase
// Este arquivo funciona em conjunto com user-progress.js

(function() {
  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // Salvar progresso no Supabase
  async function saveProgress(progressData) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      // Obter sessão do Supabase Auth
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        console.warn('Usuário não autenticado no Supabase');
        return { success: false, error: 'Usuário não autenticado' };
      }

      const userId = session.user.id;

      // Usar upsert (insert ou update) direto
      const { data, error } = await supabase
        .from('user_progress')
        .upsert({
          user_id: userId,
          completed_lessons: progressData.completedLessons || [],
          study_time_minutes: progressData.studyTime || 0,
          study_streak: progressData.studyStreak || 0,
          last_study_date: progressData.lastStudyDate || null,
          achievements: progressData.achievements || [],
          instrument_progress: progressData.instrumentProgress || {}
        }, {
          onConflict: 'user_id'
        })
        .select()
        .single();

      if (error) {
        console.error('Erro ao salvar progresso:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Progresso salvo no Supabase');
      return { success: true, data };
    } catch (error) {
      console.error('Erro ao salvar progresso:', error);
      return { success: false, error: error.message };
    }
  }

  // Carregar progresso do Supabase
  async function loadProgress() {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      // Obter sessão do Supabase Auth
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        console.warn('Usuário não autenticado no Supabase');
        return { success: false, error: 'Usuário não autenticado', data: null };
      }

      const userId = session.user.id;

      // Carregar progresso
      const { data: progress, error } = await supabase
        .from('user_progress')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116 = not found
        console.error('Erro ao carregar progresso:', error);
        return { success: false, error: error.message, data: null };
      }

      if (!progress) {
        console.log('Progresso não encontrado no Supabase - criando novo');
        return { success: false, error: 'Progresso não encontrado', data: null };
      }

      // Converter para formato do frontend
      const progressData = {
        completedLessons: progress.completed_lessons || [],
        studyTime: progress.study_time_minutes || 0,
        studyStreak: progress.study_streak || 0,
        lastStudyDate: progress.last_study_date,
        achievements: progress.achievements || [],
        instrumentProgress: progress.instrument_progress || {},
        startDate: progress.created_at
      };

      console.log('✅ Progresso carregado do Supabase');
      
      // Sincronizar com localStorage
      const localSession = JSON.parse(localStorage.getItem('ns-session') || '{}');
      if (localSession.email) {
        const storageKey = `newsong-user-progress-${localSession.email}`;
        localStorage.setItem(storageKey, JSON.stringify(progressData));
      }

      return { success: true, data: progressData };
    } catch (error) {
      console.error('Erro ao carregar progresso:', error);
      return { success: false, error: error.message, data: null };
    }
  }

  // Marcar aula como concluída
  async function markLessonComplete(lessonId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      // Carregar progresso atual
      const { success, data: currentProgress } = await loadProgress();
      
      let completedLessons = [];
      if (success && currentProgress) {
        completedLessons = currentProgress.completedLessons || [];
      }

      // Adicionar nova aula se não existir
      if (!completedLessons.includes(lessonId)) {
        completedLessons.push(lessonId);
        
        // Atualizar progresso
        const updatedProgress = {
          ...currentProgress,
          completedLessons,
          lastStudyDate: new Date().toISOString()
        };

        return await saveProgress(updatedProgress);
      }

      return { success: true };
    } catch (error) {
      console.error('Erro ao marcar aula como concluída:', error);
      return { success: false, error: error.message };
    }
  }

  // Adicionar conquista
  async function unlockAchievement(achievementId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      // Carregar progresso atual
      const { success, data: currentProgress } = await loadProgress();
      
      let achievements = [];
      if (success && currentProgress) {
        achievements = currentProgress.achievements || [];
      }

      // Adicionar nova conquista se não existir
      if (!achievements.includes(achievementId)) {
        achievements.push(achievementId);
        
        // Atualizar progresso
        const updatedProgress = {
          ...currentProgress,
          achievements
        };

        return await saveProgress(updatedProgress);
      }

      return { success: true };
    } catch (error) {
      console.error('Erro ao desbloquear conquista:', error);
      return { success: false, error: error.message };
    }
  }

  // Expor funções globalmente
  window.SupabaseProgress = {
    saveProgress,
    loadProgress,
    markLessonComplete,
    unlockAchievement
  };

  console.log('✅ SupabaseProgress module loaded');
})();
