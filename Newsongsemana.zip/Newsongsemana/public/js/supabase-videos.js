// supabase-videos.js - Integração de vídeos com Supabase
// Este arquivo funciona em conjunto com videos.js e upload.js

(function() {
  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // Salvar vídeo no Supabase
  async function saveVideo(videoData) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      // Obter sessão do Supabase Auth
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        console.warn('Usuário não autenticado no Supabase');
        return { success: false, error: 'Usuário não autenticado' };
      }

      const userId = session.user.id;
      const userName = session.user.user_metadata?.name || session.user.email.split('@')[0];

      // Preparar dados do vídeo
      const videoToInsert = {
        title: videoData.title,
        description: videoData.description || '',
        url: videoData.url || '',
        thumbnail_url: videoData.thumbnail || null,
        instrument: videoData.instrument,
        module: videoData.module,
        lesson: videoData.lesson || '',
        duration: videoData.duration || '0:00',
        uploaded_by: userId,
        uploaded_by_name: userName,
        teacher_email: session.user.email,
        views: 0,
        likes: 0,
        is_published: true,
        upload_type: videoData.uploadType || 'youtube'
      };

      console.log('📤 Enviando vídeo para Supabase:', videoToInsert);

      // Inserir no Supabase
      const { data: insertedVideo, error: insertError } = await supabase
        .from('videos')
        .insert([videoToInsert])
        .select()
        .single();

      if (insertError) {
        console.error('❌ Erro ao salvar vídeo no Supabase:', insertError);
        return { success: false, error: insertError.message };
      }

      console.log('✅ Vídeo salvo no Supabase com ID:', insertedVideo.id);

      return { success: true, data: insertedVideo };
    } catch (error) {
      console.error('❌ Erro ao salvar vídeo:', error);
      return { success: false, error: error.message };
    }
  }

  // Carregar vídeos do Supabase
  async function loadVideos(filters = {}) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      let query = supabase
        .from('videos')
        .select('*')
        .eq('is_published', true)
        .order('created_at', { ascending: false });

      // Aplicar filtros
      if (filters.instrument) {
        query = query.eq('instrument', filters.instrument);
      }
      if (filters.module) {
        query = query.eq('module', filters.module);
      }
      if (filters.lessonId) {
        query = query.eq('lesson_id', filters.lessonId);
      }

      const { data: videos, error } = await query;

      if (error) {
        console.error('❌ Erro ao carregar vídeos:', error);
        return { success: false, error: error.message, data: [] };
      }

      console.log(`✅ ${videos.length} vídeos publicados carregados do Supabase`);
      
      // DEBUG: Verificar se há vídeos não publicados
      const { data: allVideos } = await supabase
        .from('videos')
        .select('id, title, is_published')
        .order('created_at', { ascending: false });
      
      const unpublished = allVideos?.filter(v => !v.is_published) || [];
      if (unpublished.length > 0) {
        console.warn(`⚠️ ATENÇÃO: Há ${unpublished.length} vídeo(s) NÃO PUBLICADO(S) que não aparecem na lista:`);
        unpublished.forEach(v => {
          console.warn(`   - ID ${v.id}: "${v.title}" (is_published: ${v.is_published})`);
        });
        console.info('💡 Para republicar, execute no Supabase SQL Editor:');
        console.info(`   UPDATE videos SET is_published = true WHERE id IN (${unpublished.map(v => v.id).join(', ')});`);
      }

      // Mapear campos do Supabase para formato do sistema
      const mappedVideos = videos.map(v => ({
        id: v.id,
        title: v.title,
        description: v.description,
        duration: v.duration,
        author: v.uploaded_by_name || v.teacher_email,
        teacherEmail: v.teacher_email,
        instrument: v.instrument,
        module: v.module,
        lesson: v.lesson,
        uploadedAt: v.created_at,
        uploadType: v.upload_type || 'youtube',
        views: v.views || 0,
        likes: v.likes || 0,
        url: v.url,
        videoId: v.url ? extractYouTubeIdFromUrl(v.url) : null,
        thumbnail: v.thumbnail_url,
        postedDate: v.created_at
      }));

      // Sincronizar com localStorage
      localStorage.setItem('ns-videos', JSON.stringify(mappedVideos));

      return { success: true, data: mappedVideos };
    } catch (error) {
      console.error('❌ Erro ao carregar vídeos:', error);
      
      // Fallback para localStorage
      const localVideos = JSON.parse(localStorage.getItem('ns-videos') || '[]');
      return { success: false, error: error.message, data: localVideos };
    }
  }

  // Função auxiliar para extrair ID do YouTube
  function extractYouTubeIdFromUrl(url) {
    if (!url) return null;
    const patterns = [
      /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
      /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
      /(?:youtube\.com\/v\/)([a-zA-Z0-9_-]{11})/,
      /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1]) return match[1];
    }
    return null;
  }

  // Incrementar visualizações
  async function incrementViews(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      // Buscar ID do usuário
      let userId = null;
      if (session.email) {
        const { data: user } = await supabase
          .from('users')
          .select('id')
          .eq('email', session.email)
          .single();
        
        if (user) userId = user.id;
      }

      // Registrar visualização
      if (userId) {
        await supabase
          .from('video_views')
          .insert([{
            video_id: videoId,
            user_id: userId
          }]);
      }

      // Incrementar contador de views no vídeo
      const { error } = await supabase
        .rpc('increment_video_views', { video_id: videoId });

      if (error) {
        console.error('Erro ao incrementar views:', error);
      }
    } catch (error) {
      console.error('Erro ao registrar view:', error);
    }
  }

  // Salvar vídeo favorito
  async function saveVideoToFavorites(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado' };
      }

      // Inserir vídeo salvo
      const { error } = await supabase
        .from('saved_videos')
        .insert([{
          user_id: user.id,
          video_id: videoId
        }]);

      if (error) {
        console.error('Erro ao salvar vídeo favorito:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Vídeo salvo nos favoritos');
      return { success: true };
    } catch (error) {
      console.error('Erro ao salvar favorito:', error);
      return { success: false, error: error.message };
    }
  }

  // Remover vídeo dos favoritos
  async function removeVideoFromFavorites(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado' };
      }

      // Remover vídeo salvo
      const { error } = await supabase
        .from('saved_videos')
        .delete()
        .eq('user_id', user.id)
        .eq('video_id', videoId);

      if (error) {
        console.error('Erro ao remover vídeo dos favoritos:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Vídeo removido dos favoritos');
      return { success: true };
    } catch (error) {
      console.error('Erro ao remover favorito:', error);
      return { success: false, error: error.message };
    }
  }

  // Carregar vídeos salvos do usuário
  async function loadSavedVideos() {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || '{}');

      if (!session.email) {
        return { success: false, error: 'Usuário não autenticado', data: [] };
      }

      // Buscar ID do usuário
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('email', session.email)
        .single();

      if (!user) {
        return { success: false, error: 'Usuário não encontrado', data: [] };
      }

      // Carregar vídeos salvos com JOIN
      const { data: savedVideos, error } = await supabase
        .from('saved_videos')
        .select(`
          video_id,
          saved_at,
          videos (*)
        `)
        .eq('user_id', user.id)
        .order('saved_at', { ascending: false });

      if (error) {
        console.error('Erro ao carregar vídeos salvos:', error);
        return { success: false, error: error.message, data: [] };
      }

      const videos = savedVideos.map(sv => ({
        ...sv.videos,
        saved_at: sv.saved_at
      }));

      console.log(`✅ ${videos.length} vídeos salvos carregados`);
      return { success: true, data: videos };
    } catch (error) {
      console.error('Erro ao carregar vídeos salvos:', error);
      return { success: false, error: error.message, data: [] };
    }
  }

  // Expor funções globalmente
  window.SupabaseVideos = {
    saveVideo,
    loadVideos,
    incrementViews,
    saveVideoToFavorites,
    removeVideoFromFavorites,
    loadSavedVideos
  };

  console.log('✅ SupabaseVideos module loaded');
})();
