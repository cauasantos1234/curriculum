// ranking-system.js - Sistema de Ranking
(function() {
  'use strict';

  window.RankingSystem = {
    async getRankingByXP(limit = 10) {
      try {
        const supabase = window.SupabaseAPI?.getClient();
        if (!supabase) {
          console.error('❌ Cliente Supabase não disponível');
          return [];
        }
        
        let { data, error } = await supabase
          .from('ranking_by_xp')
          .select('*')
          .limit(limit);

        if (error && error.message.includes('ranking_by_xp')) {
          const result = await supabase
            .from('user_xp')
            .select('*, users:user_id(name, email)')
            .order('total_xp', { ascending: false })
            .limit(limit);
          
          if (result.error) {
            console.error('❌ Erro ao buscar ranking:', result.error);
            return [];
          }
          
          data = result.data?.map((item, index) => ({
            rank: index + 1,
            name: item.users?.name || 'Usuário',
            total_xp: item.total_xp,
            current_level: item.current_level,
            current_streak: item.current_streak
          })) || [];
        } else if (error) {
          console.error('❌ Erro ao buscar ranking por XP:', error);
          return [];
        }

        return data || [];
      } catch (error) {
        console.error('❌ Erro ao buscar ranking por XP:', error);
        return [];
      }
    },

    async getRankingByStreak(limit = 10) {
      try {
        const supabase = window.SupabaseAPI?.getClient();
        if (!supabase) {
          console.error('❌ Cliente Supabase não disponível');
          return [];
        }
        
        const { data, error } = await supabase
          .from('ranking_by_streak')
          .select('*')
          .limit(limit);

        if (error) {
          console.error('❌ Erro ao buscar ranking por streak:', error);
          return [];
        }

        return data || [];
      } catch (error) {
        console.error('❌ Erro ao buscar ranking por streak:', error);
        return [];
      }
    },

    async getCurrentUserRanking() {
      try {
        const supabase = window.SupabaseAPI?.getClient();
        if (!supabase) {
          console.error('❌ Cliente Supabase não disponível');
          return null;
        }
        
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          console.warn('⚠️ Usuário não autenticado para buscar ranking');
          return null;
        }

        // // // console.log('🔍 Buscando ranking do usuário:', session.user.id);

        const { data, error } = await supabase.rpc('get_user_ranking', {
          p_user_id: session.user.id
        });

        if (error) {
          console.error('❌ Erro ao buscar posição do usuário:', error);
          return null;
        }

        return data;
      } catch (error) {
        console.error('❌ Erro ao buscar posição do usuário:', error);
        return null;
      }
    },

    renderRankingTable(rankings, type = 'xp') {
      if (!rankings || rankings.length === 0) {
        return `
          <div class="ranking-empty-state">
            <div class="empty-icon">🏆</div>
            <h3>Seja o primeiro no ranking!</h3>
            <p>Complete aulas e ganhe XP para aparecer aqui.</p>
          </div>
        `;
      }

      let html = '<div class="ranking-grid">';

      rankings.forEach((user, index) => {
        const isTop3 = index < 3;
        const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '';
        const rankClass = isTop3 ? 'top-rank' : '';
        const rankColor = index === 0 ? '#FFD700' : index === 1 ? '#C0C0C0' : index === 2 ? '#CD7F32' : '#d4af37';
        
        const initials = this.getInitials(user.user_name || user.user_email);
        const avatarContent = user.avatar_url 
          ? `<img src="${user.avatar_url}" alt="${this.escapeHtml(user.user_name)}" class="rank-avatar-img">`
          : `<div class="rank-avatar-initials">${initials}</div>`;

        const displayName = user.user_name || user.user_email?.split('@')[0] || 'Usuário';

        html += `
          <div class="rank-card ${rankClass}" data-rank="${index + 1}" style="animation-delay: ${index * 0.05}s">
            <div class="rank-medal-area">
              <div class="rank-position" style="color: ${rankColor};">
                ${medal || `#${user.rank || (index + 1)}`}
              </div>
            </div>
            <div class="rank-user">
              <div class="rank-avatar">
                ${avatarContent}
              </div>
              <div class="rank-user-info">
                <h4 class="rank-username">${this.escapeHtml(displayName)}</h4>
                <div class="rank-badges">
                  <span class="rank-badge rank-level">
                    Nível ${user.level || 1}
                  </span>
                  ${type === 'xp' 
                    ? `<span class="rank-badge rank-xp">
                         ${(user.total_xp || 0).toLocaleString()} XP
                       </span>`
                    : `<span class="rank-badge rank-streak">
                         🔥 ${user.current_streak || 0} dias
                       </span>`
                  }
                </div>
              </div>
            </div>
            <div class="rank-stats">
              ${type === 'xp' 
                ? `<div class="rank-stat">
                     <span class="stat-label">Streak</span>
                     <span class="stat-value">${user.current_streak || 0} 🔥</span>
                   </div>`
                : `<div class="rank-stat">
                     <span class="stat-label">XP Total</span>
                     <span class="stat-value">${(user.total_xp || 0).toLocaleString()}</span>
                   </div>
                   <div class="rank-stat">
                     <span class="stat-label">Recorde</span>
                     <span class="stat-value">${user.longest_streak || 0} dias</span>
                   </div>`
              }
            </div>
          </div>
        `;
      });

      html += '</div>';
      return html;
    },

    renderUserCard(userRanking, userXP) {
      if (!userRanking || !userXP) {
        return '';
      }

      const levelProgress = XPSystem.getLevelProgress(userXP.total_xp);

      return `
        <div class="user-ranking-card">
          <div class="user-ranking-header">
            <h3>Sua Posição</h3>
          </div>
          <div class="user-ranking-content">
            <div class="user-ranking-stats">
              <div class="user-stat">
                <span class="stat-label">Ranking XP</span>
                <span class="stat-value">#${userRanking.xp_rank}</span>
              </div>
              <div class="user-stat">
                <span class="stat-label">Nível</span>
                <span class="stat-value">${levelProgress.level}</span>
              </div>
              <div class="user-stat">
                <span class="stat-label">XP Total</span>
                <span class="stat-value">${userXP.total_xp}</span>
              </div>
              <div class="user-stat">
                <span class="stat-label">Streak</span>
                <span class="stat-value">🔥 ${userXP.current_streak}</span>
              </div>
            </div>
            <div class="level-progress-container">
              <div class="level-progress-header">
                <span class="level-name">${levelProgress.levelName}</span>
                <span class="level-next">Próximo: ${levelProgress.xpNeeded} XP</span>
              </div>
              <div class="level-progress-bar">
                <div class="level-progress-fill" style="width: ${levelProgress.progress}%"></div>
              </div>
            </div>
          </div>
        </div>
      `;
    },

    getInitials(name) {
      if (!name) return 'U';
      const parts = name.trim().split(' ');
      if (parts.length >= 2) {
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
      }
      return name.substring(0, 2).toUpperCase();
    },

    escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    },

    // Atualizar ranking imediatamente
    async refreshRanking() {
      try {
        console.log('🔄 Atualizando ranking...');
        
        // Verificar se estamos na página com ranking
        const rankingContainer = document.getElementById('rankingTableContainer');
        if (!rankingContainer) {
          console.log('ℹ️ Ranking não está na página atual');
          return;
        }

        // Determinar tipo atual de ranking (XP ou Streak)
        const activeTab = document.querySelector('.ranking-tab.active');
        const rankingType = activeTab?.dataset?.type || 'xp';

        // Recarregar ranking
        let rankings;
        if (rankingType === 'xp') {
          rankings = await this.getRankingByXP(10);
        } else {
          rankings = await this.getRankingByStreak(10);
        }

        // Renderizar novo ranking
        const html = this.renderRankingTable(rankings, rankingType);
        rankingContainer.innerHTML = html;

        // Atualizar card do usuário também
        const userCardContainer = document.getElementById('currentUserRankingCard');
        if (userCardContainer && window.XPSystem) {
          try {
            const userXP = await window.XPSystem.getUserXP();
            const userRanking = await this.getCurrentUserRanking();
            
            if (userXP && userRanking) {
              userCardContainer.innerHTML = this.renderUserCard(userRanking, userXP);
            }
          } catch (error) {
            console.warn('⚠️ Não foi possível atualizar card do usuário:', error);
          }
        }

        console.log('✅ Ranking atualizado com sucesso!');
      } catch (error) {
        console.error('❌ Erro ao atualizar ranking:', error);
      }
    }
  };

})();
