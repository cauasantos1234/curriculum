# 🔧 SOLUÇÃO: Progresso Incorreto Aparecendo

## 🚨 PROBLEMA
Você está vendo progresso que não fez (de outra conta ou dados fantasmas).

## ✅ SOLUÇÃO RÁPIDA (2 passos)

### Passo 1: Limpar Cache do Navegador

1. **Abra o Console** - Pressione `F12`
2. **Vá na aba Console**
3. **Cole este código** (copie TUDO do arquivo `limpar-cache-local.js`)
4. **Execute:** `limparMinhaContaApenas()`
5. **Atualize a página** - `F5`

### Passo 2: Limpar Progresso no Supabase (Opcional)

Se ainda aparecer progresso errado:

1. Abra **Supabase SQL Editor**
2. Execute: **`limpar-progresso-incorreto.sql`**
3. Descomente a seção do seu email:
   ```sql
   DELETE FROM user_progress 
   WHERE user_id IN (
     SELECT id FROM users WHERE email = 'SEU_EMAIL@GMAIL.COM'
   );
   ```
4. Execute o script

---

## 🎯 COMANDOS DE CONSOLE DISPONÍVEIS

Cole o código do `limpar-cache-local.js` no console e use:

### `limparMinhaContaApenas()`
- ✅ Limpa apenas o progresso da conta logada
- ✅ Mantém a sessão ativa
- ✅ **RECOMENDADO para seu caso**

### `limparTodoProgresso()`
- Remove progresso de TODAS as contas
- Mantém sessão e contas salvas

### `resetarTudo()`
- ⚠️ Remove TUDO (sessão + progresso + contas)
- Faz logout automático

---

## 📝 POR QUE ISSO ACONTECE?

O sistema armazena progresso em 2 lugares:

1. **localStorage** (navegador) - Por email: `newsong-user-progress-email@gmail.com`
2. **Supabase** (banco de dados) - Por user_id na tabela `user_progress`

Quando você troca de conta, o localStorage pode ter dados antigos que "vazam" para a nova sessão.

---

## 🔍 DIAGNÓSTICO

Para ver o que está armazenado, cole no console:

```javascript
// Ver sessão atual
JSON.parse(localStorage.getItem('ns-session'))

// Ver progresso da conta atual
const session = JSON.parse(localStorage.getItem('ns-session'));
const key = `newsong-user-progress-${session.email}`;
JSON.parse(localStorage.getItem(key));

// Ver TODOS os progressos salvos
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  if (key.startsWith('newsong-user-progress-')) {
    console.log(key, localStorage.getItem(key).substring(0, 100));
  }
}
```

---

## ✅ DEPOIS DE LIMPAR

1. Faça **logout** - `SupabaseAdmin.logout()` no console
2. Faça **login novamente**
3. O progresso deve estar zerado
4. Agora tudo que você fizer será salvo corretamente

---

## 🆘 SE AINDA NÃO FUNCIONAR

Execute no Supabase:

```sql
-- Ver seu progresso atual
SELECT * FROM user_progress 
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'SEU_EMAIL@GMAIL.COM'
);

-- Deletar progresso incorreto
DELETE FROM user_progress 
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'SEU_EMAIL@GMAIL.COM'
);
```

Depois atualize o navegador (`Ctrl+F5`).
