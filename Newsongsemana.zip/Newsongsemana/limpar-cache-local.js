// ============================================================================
// LIMPAR CACHE LOCAL - Cole este código no CONSOLE do navegador
// ============================================================================
// Este script limpa o progresso armazenado localmente no navegador
// ============================================================================

console.log('🧹 Iniciando limpeza de cache local...\n');

// 1. Ver o que tem armazenado
console.log('📦 Itens no localStorage:');
for (let i = 0; i < localStorage.length; i++) {
  const key = localStorage.key(i);
  if (key.includes('newsong') || key.includes('ns-')) {
    const value = localStorage.getItem(key);
    console.log(`  ${key}:`, value.substring(0, 100) + '...');
  }
}

// 2. Ver sessão atual
const currentSession = JSON.parse(localStorage.getItem('ns-session') || 'null');
if (currentSession) {
  console.log('\n👤 Sessão atual:');
  console.log('  Email:', currentSession.email);
  console.log('  Nome:', currentSession.name);
  console.log('  Tipo:', currentSession.role);
} else {
  console.log('\n❌ Nenhuma sessão ativa');
}

// 3. FUNÇÃO PARA LIMPAR PROGRESSO DE TODAS AS CONTAS
window.limparTodoProgresso = function() {
  console.log('\n🗑️ Removendo progresso de TODAS as contas...');
  
  let removed = 0;
  const keysToRemove = [];
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('newsong-user-progress-')) {
      keysToRemove.push(key);
    }
  }
  
  keysToRemove.forEach(key => {
    localStorage.removeItem(key);
    console.log(`  ✅ Removido: ${key}`);
    removed++;
  });
  
  console.log(`\n✅ ${removed} progresso(s) removido(s)!`);
  console.log('🔄 Atualize a página (F5) para recarregar progresso do Supabase');
};

// 4. FUNÇÃO PARA LIMPAR APENAS A CONTA ATUAL
window.limparMinhaContaApenas = function() {
  const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
  
  if (!session) {
    console.error('❌ Nenhuma sessão ativa! Faça login primeiro.');
    return;
  }
  
  const progressKey = `newsong-user-progress-${session.email}`;
  
  console.log(`\n🗑️ Removendo progresso de: ${session.email}`);
  localStorage.removeItem(progressKey);
  console.log(`✅ Progresso removido de ${progressKey}`);
  console.log('🔄 Atualize a página (F5) para recarregar progresso do Supabase');
};

// 5. FUNÇÃO PARA RESETAR COMPLETAMENTE
window.resetarTudo = function() {
  console.log('\n⚠️ RESETANDO TUDO...');
  
  const confirm = window.confirm('⚠️ ATENÇÃO: Isso vai remover TODOS os dados locais incluindo sessão, progresso e contas.\n\nDeseja continuar?');
  
  if (!confirm) {
    console.log('❌ Cancelado pelo usuário');
    return;
  }
  
  // Remover tudo relacionado ao NewSong
  const keysToRemove = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && (key.includes('newsong') || key.includes('ns-'))) {
      keysToRemove.push(key);
    }
  }
  
  keysToRemove.forEach(key => {
    localStorage.removeItem(key);
    console.log(`  🗑️ Removido: ${key}`);
  });
  
  console.log(`\n✅ ${keysToRemove.length} item(s) removido(s)!`);
  console.log('🔄 Redirecionando para login...');
  
  setTimeout(() => {
    window.location.href = 'login.html';
  }, 2000);
};

// 6. INSTRUÇÕES
console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('📋 COMANDOS DISPONÍVEIS:');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('');
console.log('  limparMinhaContaApenas()');
console.log('  └─ Limpa apenas o progresso da conta logada atualmente');
console.log('');
console.log('  limparTodoProgresso()');
console.log('  └─ Remove progresso de TODAS as contas (mantém sessão)');
console.log('');
console.log('  resetarTudo()');
console.log('  └─ ⚠️ REMOVE TUDO (sessão + progresso + contas locais)');
console.log('');
console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
console.log('');
console.log('💡 RECOMENDADO PARA SEU CASO:');
console.log('   Digite: limparMinhaContaApenas()');
console.log('   Depois pressione F5 para atualizar');
console.log('');
