# 🔍 GUIA: Ver TODOS os Logins/Contas do Supabase

## 📋 Problema
A página `supabase-admin.html` só mostra usuários da tabela `users`, que contém apenas usuários que **já fizeram login ao menos uma vez**. Contas criadas (signUp) mas que nunca logaram (signIn) não aparecem nessa tabela.

## ⚠️ Diferença Importante
- **Criar conta (signUp)**: Cria registro no `auth.users` do Supabase
- **Fazer login (signIn)**: Cria sessão E pode criar registro na tabela `users` customizada

## 🎯 3 Formas de Ver TODAS as Contas (Incluindo Não-Logadas)

### ✅ Opção 1: Dashboard do Supabase (MAIS FÁCIL)
1. Acesse https://supabase.com/dashboard
2. Selecione seu projeto
3. Vá em **Authentication → Users**
4. Lá você verá TODAS as contas criadas, incluindo:
   - ✅ Contas que já logaram
   - ⚠️ Contas criadas mas que nunca logaram
   - 📧 Status de confirmação de email
   - 📅 Data de criação e último login

### 🔧 Opção 2: SQL Editor (Query Rápida)
Execute no SQL Editor do Supabase:
```sql
SELECT 
  id,
  email, 
  created_at,
  last_sign_in_at,
  email_confirmed_at,
  raw_user_meta_data->>'role' as role,
  CASE 
    WHEN last_sign_in_at IS NOT NULL THEN 'Já logou'
    ELSE 'Nunca logou'
  END as status
FROM auth.users 
ORDER BY created_at DESC;
```

### 🔨 Opção 3: Criar Função SQL (Solução Permanente)
Execute o arquivo SQL criado:
1. Abra o SQL Editor no Supabase
2. Execute o conteúdo do arquivo: `database/create-get-all-users-function.sql`
3. Depois, na página `supabase-admin.html`, clique em **"🔍 Ver Usuários de Auth"**
4. A função criada permitirá ver todos os usuários diretamente no painel!

## 📊 O Que Você Verá
- **Total de contas criadas**
- **Quantas já fizeram login**
- **Quantas nunca logaram**
- **Email de cada conta**
- **Data de criação**
- **Data do último login** (ou "Nunca")
- **Status de confirmação de email**

## 🚀 Recomendação
Use a **Opção 1 (Dashboard)** para verificar rapidamente.
Use a **Opção 3 (Função SQL)** se quiser ter essa informação sempre disponível no painel admin.

## 📝 Notas Importantes
- Contas criadas aparecem **imediatamente** no `auth.users`
- A tabela `users` customizada só é populada **após o primeiro login**
- O painel atual mostra apenas quem está na tabela `users`
- Para ver TODOS (incluindo nunca-logados), use as opções acima
