-- ========================================
-- FIX: PERMITIR REGISTRO DE USUÁRIOS
-- ========================================
-- Este SQL resolve o problema de contas não aparecendo no banco
-- Problema: Políticas RLS bloqueando INSERT na tabela users
-- Solução: Criar políticas que permitem registro público

-- ========================================
-- 1. HABILITAR RLS (Row Level Security)
-- ========================================
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- ========================================
-- 2. REMOVER POLÍTICAS ANTIGAS (se existirem)
-- ========================================
DROP POLICY IF EXISTS "Allow insert users" ON users;
DROP POLICY IF EXISTS "Allow select users" ON users;
DROP POLICY IF EXISTS "Allow update own user" ON users;
DROP POLICY IF EXISTS "Allow delete own user" ON users;
DROP POLICY IF EXISTS "Enable insert for authentication" ON users;
DROP POLICY IF EXISTS "Enable read access for all users" ON users;

-- ========================================
-- 3. CRIAR POLÍTICA: PERMITIR INSERT (REGISTRO)
-- ========================================
-- Esta política permite que QUALQUER PESSOA crie uma conta
-- Necessário para o registro funcionar
CREATE POLICY "Allow insert users" 
ON users FOR INSERT 
WITH CHECK (true);

-- ========================================
-- 4. CRIAR POLÍTICA: PERMITIR SELECT (LEITURA)
-- ========================================
-- Permite ler dados de usuários (necessário para login e painel admin)
CREATE POLICY "Allow select users" 
ON users FOR SELECT 
USING (true);

-- ========================================
-- 5. CRIAR POLÍTICA: PERMITIR UPDATE (ATUALIZAÇÃO)
-- ========================================
-- Permite que usuários atualizem apenas seus próprios dados
CREATE POLICY "Allow update own user" 
ON users FOR UPDATE 
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- ========================================
-- 6. CRIAR POLÍTICA: PERMITIR DELETE (OPCIONAL)
-- ========================================
-- Permite que usuários deletem apenas suas próprias contas
CREATE POLICY "Allow delete own user" 
ON users FOR DELETE 
USING (auth.uid() = id);

-- ========================================
-- 7. VERIFICAR POLÍTICAS CRIADAS
-- ========================================
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'users'
ORDER BY policyname;

-- ========================================
-- 8. TESTAR INSERT
-- ========================================
-- Tentar inserir um usuário de teste
DO $$
DECLARE
  test_id uuid := gen_random_uuid();
BEGIN
  -- Inserir usuário teste
  INSERT INTO users (id, email, name, role, is_active, created_at)
  VALUES (
    test_id,
    'teste_rls_' || extract(epoch from now()) || '@gmail.com',
    'Teste RLS',
    'student',
    true,
    now()
  );
  
  -- Verificar se foi inserido
  IF EXISTS (SELECT 1 FROM users WHERE id = test_id) THEN
    RAISE NOTICE '✅ INSERT funcionando! Usuário teste criado com ID: %', test_id;
    
    -- Remover usuário teste
    DELETE FROM users WHERE id = test_id;
    RAISE NOTICE '✅ Usuário teste removido';
  ELSE
    RAISE NOTICE '❌ ERRO: Não foi possível inserir usuário teste';
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE '❌ ERRO ao testar: %', SQLERRM;
END $$;

-- ========================================
-- 9. RESUMO
-- ========================================
SELECT 
  '✅ Configuração Completa!' as status,
  (SELECT count(*) FROM pg_policies WHERE tablename = 'users') as total_politicas,
  (SELECT count(*) FROM users) as total_usuarios,
  now() as executado_em;

-- ========================================
-- INSTRUÇÕES PÓS-EXECUÇÃO
-- ========================================
-- 1. Execute este SQL completo no SQL Editor do Supabase
-- 2. Abra o painel admin (supabase-admin.html)
-- 3. Clique em "🔍 Diagnosticar Registro"
-- 4. Deve aparecer "✅ Tudo Funcionando!"
-- 5. Tente criar uma nova conta em register.html
-- 6. A conta deve aparecer IMEDIATAMENTE na lista de usuários!
-- ========================================
