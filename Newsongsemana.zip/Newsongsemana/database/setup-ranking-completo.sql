-- =====================================================
-- SETUP COMPLETO DO SISTEMA DE RANKING
-- Execute este script no Supabase SQL Editor
-- =====================================================

-- Ativar extensão UUID se ainda não estiver
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- TABELA: user_xp
-- Armazena XP total, nível e streak de cada usuário
-- =====================================================
CREATE TABLE IF NOT EXISTS user_xp (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  total_xp INTEGER DEFAULT 0 NOT NULL,
  level INTEGER DEFAULT 1 NOT NULL,
  current_streak INTEGER DEFAULT 0 NOT NULL,
  longest_streak INTEGER DEFAULT 0 NOT NULL,
  last_activity_date DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_user_xp_user_id ON user_xp(user_id);
CREATE INDEX IF NOT EXISTS idx_user_xp_total_xp ON user_xp(total_xp DESC);
CREATE INDEX IF NOT EXISTS idx_user_xp_current_streak ON user_xp(current_streak DESC);

-- =====================================================
-- TABELA: xp_transactions
-- Registra cada ganho de XP para auditoria e histórico
-- =====================================================
CREATE TABLE IF NOT EXISTS xp_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  xp_amount INTEGER NOT NULL,
  action_type VARCHAR(50) NOT NULL,
  reference_id UUID,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_xp_transactions_user_id ON xp_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_xp_transactions_created_at ON xp_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_xp_transactions_action_type ON xp_transactions(action_type);

-- =====================================================
-- FUNÇÃO: Calcular nível baseado em XP
-- =====================================================
CREATE OR REPLACE FUNCTION calculate_level(xp INTEGER)
RETURNS INTEGER AS $$
DECLARE
  calculated_level INTEGER;
BEGIN
  IF xp <= 100 THEN
    calculated_level := 1;
  ELSIF xp <= 300 THEN
    calculated_level := 2;
  ELSIF xp <= 600 THEN
    calculated_level := 3;
  ELSIF xp <= 1000 THEN
    calculated_level := 4;
  ELSIF xp <= 1500 THEN
    calculated_level := 5;
  ELSE
    calculated_level := 6 + FLOOR((xp - 1500) / 500);
  END IF;
  
  RETURN calculated_level;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- FUNÇÃO: Adicionar XP ao usuário
-- =====================================================
CREATE OR REPLACE FUNCTION add_xp_to_user(
  p_user_id UUID,
  p_xp_amount INTEGER,
  p_action_type VARCHAR(50),
  p_reference_id UUID DEFAULT NULL,
  p_description TEXT DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
  v_user_xp_record RECORD;
  v_new_total_xp INTEGER;
  v_new_level INTEGER;
  v_level_up BOOLEAN := FALSE;
BEGIN
  -- Buscar ou criar registro de XP do usuário
  SELECT * INTO v_user_xp_record FROM user_xp WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    INSERT INTO user_xp (user_id, total_xp, level, last_activity_date)
    VALUES (p_user_id, 0, 1, CURRENT_DATE)
    RETURNING * INTO v_user_xp_record;
  END IF;
  
  -- Calcular novo total de XP
  v_new_total_xp := v_user_xp_record.total_xp + p_xp_amount;
  v_new_level := calculate_level(v_new_total_xp);
  
  -- Verificar se subiu de nível
  IF v_new_level > v_user_xp_record.level THEN
    v_level_up := TRUE;
  END IF;
  
  -- Atualizar XP do usuário
  UPDATE user_xp
  SET 
    total_xp = v_new_total_xp,
    level = v_new_level,
    updated_at = NOW()
  WHERE user_id = p_user_id;
  
  -- Registrar transação
  INSERT INTO xp_transactions (user_id, xp_amount, action_type, reference_id, description)
  VALUES (p_user_id, p_xp_amount, p_action_type, p_reference_id, p_description);
  
  RETURN json_build_object(
    'success', TRUE,
    'xp_gained', p_xp_amount,
    'total_xp', v_new_total_xp,
    'level', v_new_level,
    'level_up', v_level_up
  );
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- VIEW: Ranking Global por XP
-- =====================================================
DROP VIEW IF EXISTS ranking_by_xp CASCADE;

CREATE OR REPLACE VIEW ranking_by_xp AS
SELECT 
  ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC, ux.created_at ASC) as rank,
  ux.user_id,
  ux.total_xp,
  ux.level,
  ux.current_streak,
  ux.longest_streak,
  COALESCE(u.email, 'Usuário') as user_name,
  u.email as user_email,
  NULL as avatar_url
FROM user_xp ux
LEFT JOIN auth.users u ON ux.user_id = u.id
ORDER BY ux.total_xp DESC, ux.created_at ASC
LIMIT 100;

-- =====================================================
-- VIEW: Ranking por Streak
-- =====================================================
DROP VIEW IF EXISTS ranking_by_streak CASCADE;

CREATE OR REPLACE VIEW ranking_by_streak AS
SELECT 
  ROW_NUMBER() OVER (ORDER BY ux.current_streak DESC, ux.total_xp DESC) as rank,
  ux.user_id,
  ux.current_streak,
  ux.longest_streak,
  ux.total_xp,
  ux.level,
  COALESCE(u.email, 'Usuário') as user_name,
  u.email as user_email,
  NULL as avatar_url
FROM user_xp ux
LEFT JOIN auth.users u ON ux.user_id = u.id
WHERE ux.current_streak > 0
ORDER BY ux.current_streak DESC, ux.total_xp DESC
LIMIT 100;

-- =====================================================
-- FUNÇÃO: Buscar ranking do usuário
-- =====================================================
DROP FUNCTION IF EXISTS get_user_ranking(UUID);

CREATE OR REPLACE FUNCTION get_user_ranking(p_user_id UUID)
RETURNS JSON AS $$
DECLARE
  v_xp_rank INTEGER;
  v_streak_rank INTEGER;
  v_user_data RECORD;
BEGIN
  -- Buscar dados do usuário
  SELECT * INTO v_user_data FROM user_xp WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    RETURN json_build_object('success', FALSE, 'error', 'User not found');
  END IF;
  
  -- Calcular posição no ranking de XP
  SELECT COUNT(*) + 1 INTO v_xp_rank
  FROM user_xp
  WHERE total_xp > v_user_data.total_xp
     OR (total_xp = v_user_data.total_xp AND created_at < v_user_data.created_at);
  
  -- Calcular posição no ranking de streak
  SELECT COUNT(*) + 1 INTO v_streak_rank
  FROM user_xp
  WHERE current_streak > v_user_data.current_streak
     OR (current_streak = v_user_data.current_streak AND total_xp > v_user_data.total_xp);
  
  RETURN json_build_object(
    'success', TRUE,
    'xp_rank', v_xp_rank,
    'streak_rank', v_streak_rank,
    'total_xp', v_user_data.total_xp,
    'level', v_user_data.level,
    'current_streak', v_user_data.current_streak,
    'longest_streak', v_user_data.longest_streak
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- PERMISSÕES
-- =====================================================
GRANT SELECT ON user_xp TO anon, authenticated;
GRANT SELECT ON xp_transactions TO anon, authenticated;
GRANT SELECT ON ranking_by_xp TO anon, authenticated;
GRANT SELECT ON ranking_by_streak TO anon, authenticated;
GRANT EXECUTE ON FUNCTION calculate_level(INTEGER) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION add_xp_to_user(UUID, INTEGER, VARCHAR, UUID, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION get_user_ranking(UUID) TO anon, authenticated;

-- =====================================================
-- POPULAR DADOS INICIAIS PARA USUÁRIOS EXISTENTES
-- =====================================================
DO $$
DECLARE
  v_user RECORD;
  v_random_xp INTEGER;
  v_random_streak INTEGER;
  v_count INTEGER := 0;
BEGIN
  RAISE NOTICE 'Populando dados de XP para usuários existentes...';
  
  FOR v_user IN SELECT id FROM auth.users LOOP
    -- Verificar se já tem registro
    IF NOT EXISTS (SELECT 1 FROM user_xp WHERE user_id = v_user.id) THEN
      -- Gerar XP aleatório entre 0 e 1500
      v_random_xp := FLOOR(RANDOM() * 1500);
      -- Gerar streak aleatório entre 0 e 30
      v_random_streak := FLOOR(RANDOM() * 30);
      
      INSERT INTO user_xp (user_id, total_xp, level, current_streak, longest_streak, last_activity_date)
      VALUES (
        v_user.id,
        v_random_xp,
        calculate_level(v_random_xp),
        v_random_streak,
        v_random_streak,
        CURRENT_DATE
      );
      
      v_count := v_count + 1;
    END IF;
  END LOOP;
  
  RAISE NOTICE '✅ % usuários populados com dados de XP', v_count;
END $$;

-- =====================================================
-- VERIFICAÇÃO FINAL
-- =====================================================
DO $$
DECLARE
  v_xp_count INTEGER;
  v_streak_count INTEGER;
  v_users_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_users_count FROM user_xp;
  SELECT COUNT(*) INTO v_xp_count FROM ranking_by_xp;
  SELECT COUNT(*) INTO v_streak_count FROM ranking_by_streak;
  
  RAISE NOTICE '========================================';
  RAISE NOTICE '✅ SETUP DO RANKING CONCLUÍDO!';
  RAISE NOTICE '========================================';
  RAISE NOTICE 'Total de usuários com XP: %', v_users_count;
  RAISE NOTICE 'Ranking por XP: % usuários', v_xp_count;
  RAISE NOTICE 'Ranking por Streak: % usuários', v_streak_count;
  RAISE NOTICE '========================================';
  
  IF v_users_count = 0 THEN
    RAISE WARNING '⚠️  Nenhum usuário encontrado! Crie usuários primeiro.';
  END IF;
END $$;

-- Mostrar Top 10 do Ranking por XP
SELECT '📊 TOP 10 RANKING POR XP' as info;
SELECT rank, user_name, total_xp, level, current_streak 
FROM ranking_by_xp 
LIMIT 10;

-- Mostrar Top 10 do Ranking por Streak
SELECT '🔥 TOP 10 RANKING POR STREAK' as info;
SELECT rank, user_name, current_streak, total_xp, level 
FROM ranking_by_streak 
LIMIT 10;
