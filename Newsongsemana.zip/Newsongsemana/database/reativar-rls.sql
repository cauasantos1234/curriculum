-- ============================================================================
-- REATIVAR RLS COM POLITICAS FUNCIONAIS
-- ============================================================================
-- Este script reativa o RLS e cria políticas que permitem o funcionamento
-- ============================================================================

-- 1. REATIVAR RLS nas tabelas
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

SELECT 'RLS REATIVADO nas tabelas users e user_progress' as status;

-- 2. REMOVER políticas antigas (limpeza)
DROP POLICY IF EXISTS "users_select_any" ON users;
DROP POLICY IF EXISTS "users_update_any" ON users;
DROP POLICY IF EXISTS "users_insert_any" ON users;
DROP POLICY IF EXISTS "progress_select_all" ON user_progress;
DROP POLICY IF EXISTS "progress_insert_all" ON user_progress;
DROP POLICY IF EXISTS "progress_update_all" ON user_progress;
DROP POLICY IF EXISTS "progress_delete_all" ON user_progress;

SELECT 'Politicas antigas removidas' as status;

-- 3. CRIAR políticas permissivas para USERS
CREATE POLICY "users_select_all"
ON users FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "users_insert_all"
ON users FOR INSERT
TO authenticated, anon
WITH CHECK (true);

CREATE POLICY "users_update_all"
ON users FOR UPDATE
TO authenticated, anon
USING (true)
WITH CHECK (true);

SELECT 'Politicas criadas para tabela USERS' as status;

-- 4. CRIAR políticas permissivas para USER_PROGRESS
CREATE POLICY "progress_select_all"
ON user_progress FOR SELECT
TO authenticated, anon
USING (true);

CREATE POLICY "progress_insert_all"
ON user_progress FOR INSERT
TO authenticated, anon
WITH CHECK (true);

CREATE POLICY "progress_update_all"
ON user_progress FOR UPDATE
TO authenticated, anon
USING (true)
WITH CHECK (true);

CREATE POLICY "progress_delete_all"
ON user_progress FOR DELETE
TO authenticated, anon
USING (true);

SELECT 'Politicas criadas para tabela USER_PROGRESS' as status;

-- 5. GARANTIR permissões
GRANT ALL ON users TO authenticated, anon;
GRANT ALL ON user_progress TO authenticated, anon;

SELECT 'Permissoes concedidas' as status;

-- 6. SINCRONIZAR contas do auth.users para users
INSERT INTO users (
  id,
  email,
  name,
  password_hash,
  created_at,
  is_active,
  role
)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', SPLIT_PART(au.email, '@', 1)),
  'FROM_AUTH',
  au.created_at,
  true,
  COALESCE(au.raw_user_meta_data->>'role', 'student')
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
WHERE u.id IS NULL
ON CONFLICT (id) DO UPDATE
SET 
  email = EXCLUDED.email,
  name = EXCLUDED.name,
  role = EXCLUDED.role;

SELECT 'Contas sincronizadas do auth.users' as status;

-- 7. Verificar resultado
SELECT 'VERIFICACAO FINAL:' as info;

SELECT 
  tablename,
  rowsecurity as rls_ativo
FROM pg_tables
WHERE tablename IN ('users', 'user_progress');

SELECT 
  'Total de usuarios em auth.users:' as metrica,
  COUNT(*)::text as valor
FROM auth.users
UNION ALL
SELECT 
  'Total de usuarios sincronizados:',
  COUNT(*)::text
FROM users
UNION ALL
SELECT 
  'Politicas em users:',
  COUNT(*)::text
FROM pg_policies
WHERE tablename = 'users'
UNION ALL
SELECT 
  'Politicas em user_progress:',
  COUNT(*)::text
FROM pg_policies
WHERE tablename = 'user_progress';
