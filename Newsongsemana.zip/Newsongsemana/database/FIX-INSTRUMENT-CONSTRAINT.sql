-- ============================================================================
-- FIX CONSTRAINT - Remover NOT NULL de colunas opcionais em user_progress
-- ============================================================================
-- Este script remove constraints NOT NULL que estão causando erros
-- ============================================================================

-- 1. Verificar estrutura atual
SELECT 
  '📋 Colunas NOT NULL em user_progress:' as info;

SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'user_progress'
AND is_nullable = 'NO'
ORDER BY ordinal_position;

-- 2. Tornar colunas opcionais (permitir NULL)
ALTER TABLE user_progress ALTER COLUMN instrument DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN module DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN lesson_id DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN completed DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN progress_percentage DROP NOT NULL;

-- 3. Adicionar valores padrão para evitar NULL
ALTER TABLE user_progress ALTER COLUMN completed SET DEFAULT false;
ALTER TABLE user_progress ALTER COLUMN progress_percentage SET DEFAULT 0;

-- 4. Verificar resultado
SELECT 
  '✅ COLUNAS AJUSTADAS!' as status;

SELECT 
  column_name,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;
