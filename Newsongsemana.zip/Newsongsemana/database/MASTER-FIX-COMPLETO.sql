-- ============================================================================
-- 🔧 MASTER FIX - Corrige TODOS os erros 406/403/400
-- ============================================================================
-- Execute ESTE script completo no Supabase SQL Editor
-- Ele corrige user_progress + users + auth em uma única execução
-- ============================================================================

-- ============================================================================
-- PARTE 1: SINCRONIZAR AUTH COM USERS
-- ============================================================================

-- 1.1: Garantir que RLS está habilitado em users
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- 1.2: Remover políticas antigas de users
DROP POLICY IF EXISTS "Usuários veem apenas próprio perfil" ON users;
DROP POLICY IF EXISTS "Usuários atualizam próprio perfil" ON users;
DROP POLICY IF EXISTS "allow_authenticated_users_select" ON users;
DROP POLICY IF EXISTS "allow_authenticated_users_update" ON users;
DROP POLICY IF EXISTS "users_select_own" ON users;
DROP POLICY IF EXISTS "users_update_own" ON users;

-- 1.3: Criar políticas PERMISSIVAS para users
CREATE POLICY "users_select_any"
ON users FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "users_update_any"
ON users FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

-- 1.4: Conceder permissões em users
GRANT SELECT, UPDATE ON users TO authenticated;

-- 1.5: Adicionar colunas faltantes na tabela users
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255);
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT true;
ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'student';
ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(255);
ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 1.6: Sincronizar usuários de auth.users para users
INSERT INTO users (
  id,
  email,
  name,
  password_hash,
  created_at,
  is_active,
  role
)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', SPLIT_PART(au.email, '@', 1)),
  'SYNCED_FROM_AUTH',
  au.created_at,
  true,
  'student'
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
WHERE u.id IS NULL
ON CONFLICT (id) DO NOTHING;

-- ============================================================================
-- PARTE 2: CORRIGIR USER_PROGRESS
-- ============================================================================

-- 2.1: Adicionar colunas faltantes
ALTER TABLE user_progress 
  ADD COLUMN IF NOT EXISTS completed_lessons INTEGER[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS study_time_minutes INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS study_streak INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_study_date TIMESTAMP WITH TIME ZONE,
  ADD COLUMN IF NOT EXISTS achievements TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS instrument_progress JSONB DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 2.2: Ajustar constraints
ALTER TABLE user_progress DROP CONSTRAINT IF EXISTS user_progress_user_id_lesson_id_key;

-- Tornar colunas opcionais (permitir NULL para evitar erros de constraint)
ALTER TABLE user_progress ALTER COLUMN lesson_id DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN instrument DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN module DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN completed DROP NOT NULL;
ALTER TABLE user_progress ALTER COLUMN progress_percentage DROP NOT NULL;

-- Adicionar valores padrão
ALTER TABLE user_progress ALTER COLUMN completed SET DEFAULT false;
ALTER TABLE user_progress ALTER COLUMN progress_percentage SET DEFAULT 0;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'user_progress_user_id_key'
  ) THEN
    ALTER TABLE user_progress ADD CONSTRAINT user_progress_user_id_key UNIQUE (user_id);
  END IF;
END $$;

-- 2.3: Criar índices
CREATE INDEX IF NOT EXISTS idx_progress_last_study ON user_progress(last_study_date DESC);
CREATE INDEX IF NOT EXISTS idx_progress_streak ON user_progress(study_streak DESC);

-- 2.4: Remover TODAS as políticas antigas
DROP POLICY IF EXISTS "Usuários veem apenas próprio progresso" ON user_progress;
DROP POLICY IF EXISTS "Usuários podem registrar próprio progresso" ON user_progress;
DROP POLICY IF EXISTS "Usuários podem atualizar próprio progresso" ON user_progress;
DROP POLICY IF EXISTS "users_select_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_insert_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_update_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_delete_own_progress" ON user_progress;
DROP POLICY IF EXISTS "enable_select_own_progress" ON user_progress;
DROP POLICY IF EXISTS "enable_insert_own_progress" ON user_progress;
DROP POLICY IF EXISTS "enable_update_own_progress" ON user_progress;
DROP POLICY IF EXISTS "enable_delete_own_progress" ON user_progress;
DROP POLICY IF EXISTS "allow_authenticated_select" ON user_progress;
DROP POLICY IF EXISTS "allow_authenticated_insert" ON user_progress;
DROP POLICY IF EXISTS "allow_authenticated_update" ON user_progress;
DROP POLICY IF EXISTS "allow_authenticated_delete" ON user_progress;

-- 2.5: Criar políticas PERMISSIVAS
CREATE POLICY "progress_select_all"
ON user_progress FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "progress_insert_all"
ON user_progress FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "progress_update_all"
ON user_progress FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "progress_delete_all"
ON user_progress FOR DELETE
TO authenticated
USING (true);

-- 2.6: Garantir RLS habilitado
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- 2.7: Conceder permissões
GRANT SELECT, INSERT, UPDATE, DELETE ON user_progress TO authenticated;

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_class WHERE relname = 'user_progress_id_seq' AND relkind = 'S'
  ) THEN
    GRANT USAGE, SELECT ON SEQUENCE user_progress_id_seq TO authenticated;
  END IF;
END $$;

-- ============================================================================
-- PARTE 3: FUNÇÕES AUXILIARES
-- ============================================================================

-- 3.1: Função de upsert otimizada
CREATE OR REPLACE FUNCTION upsert_user_progress(
  p_user_id UUID,
  p_completed_lessons INTEGER[],
  p_study_time_minutes INTEGER,
  p_study_streak INTEGER,
  p_last_study_date TIMESTAMP WITH TIME ZONE,
  p_achievements TEXT[],
  p_instrument_progress JSONB
)
RETURNS user_progress AS $$
DECLARE
  v_progress user_progress;
BEGIN
  INSERT INTO user_progress (
    user_id,
    completed_lessons,
    study_time_minutes,
    study_streak,
    last_study_date,
    achievements,
    instrument_progress
  ) VALUES (
    p_user_id,
    p_completed_lessons,
    p_study_time_minutes,
    p_study_streak,
    p_last_study_date,
    p_achievements,
    p_instrument_progress
  )
  ON CONFLICT (user_id) DO UPDATE
  SET
    completed_lessons = EXCLUDED.completed_lessons,
    study_time_minutes = EXCLUDED.study_time_minutes,
    study_streak = EXCLUDED.study_streak,
    last_study_date = EXCLUDED.last_study_date,
    achievements = EXCLUDED.achievements,
    instrument_progress = EXCLUDED.instrument_progress
  RETURNING * INTO v_progress;
  
  RETURN v_progress;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- PARTE 4: VERIFICAÇÃO FINAL
-- ============================================================================

SELECT 
  '🎉 CORREÇÃO MASTER CONCLUÍDA!' as status,
  '' as info
UNION ALL
SELECT 
  '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
  ''
UNION ALL
SELECT 
  '👥 Usuários em auth.users:',
  COUNT(*)::text
FROM auth.users
UNION ALL
SELECT 
  '📊 Usuários na tabela users:',
  COUNT(*)::text
FROM users
UNION ALL
SELECT 
  '🔗 Usuários sincronizados:',
  COUNT(*)::text
FROM users u
INNER JOIN auth.users au ON u.id = au.id
UNION ALL
SELECT 
  '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
  ''
UNION ALL
SELECT 
  '📋 Colunas em user_progress:',
  COUNT(*)::text
FROM information_schema.columns
WHERE table_name = 'user_progress'
UNION ALL
SELECT 
  '🔒 Políticas RLS (users):',
  COUNT(*)::text
FROM pg_policies 
WHERE tablename = 'users'
UNION ALL
SELECT 
  '🔒 Políticas RLS (user_progress):',
  COUNT(*)::text
FROM pg_policies 
WHERE tablename = 'user_progress'
UNION ALL
SELECT 
  '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
  ''
UNION ALL
SELECT 
  '✅ Tudo pronto! Atualize o navegador (Ctrl+F5)',
  '';
