-- ============================================================================
-- FIX USER_PROGRESS - Adicionar Colunas Faltantes
-- ============================================================================
-- Este script adiciona as colunas que o frontend espera encontrar
-- ============================================================================

-- 1. Adicionar colunas faltantes à tabela user_progress
ALTER TABLE user_progress 
  ADD COLUMN IF NOT EXISTS completed_lessons INTEGER[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS study_time_minutes INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS study_streak INTEGER DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_study_date TIMESTAMP WITH TIME ZONE,
  ADD COLUMN IF NOT EXISTS achievements TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS instrument_progress JSONB DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 2. Atualizar constraint UNIQUE para permitir um registro por usuário
-- (ao invés de um registro por usuário+lição)
ALTER TABLE user_progress DROP CONSTRAINT IF EXISTS user_progress_user_id_lesson_id_key;

-- 3. Adicionar constraint UNIQUE apenas em user_id
-- (Cada usuário tem apenas 1 registro de progresso geral)
ALTER TABLE user_progress ADD CONSTRAINT user_progress_user_id_key UNIQUE (user_id);

-- 4. Tornar lesson_id opcional (NULL permitido)
ALTER TABLE user_progress ALTER COLUMN lesson_id DROP NOT NULL;

-- 5. Criar índices para as novas colunas
CREATE INDEX IF NOT EXISTS idx_progress_last_study ON user_progress(last_study_date DESC);
CREATE INDEX IF NOT EXISTS idx_progress_streak ON user_progress(study_streak DESC);

-- 6. Migrar dados existentes (se houver)
-- Agrupar múltiplos registros de lições em um único registro de usuário
INSERT INTO user_progress (
  user_id,
  completed_lessons,
  study_time_minutes,
  study_streak,
  last_study_date,
  created_at
)
SELECT 
  user_id,
  ARRAY_AGG(DISTINCT lesson_id) FILTER (WHERE completed = true) as completed_lessons,
  0 as study_time_minutes,
  0 as study_streak,
  MAX(last_accessed) as last_study_date,
  MIN(last_accessed) as created_at
FROM user_progress
WHERE lesson_id IS NOT NULL
GROUP BY user_id
ON CONFLICT (user_id) DO UPDATE
SET 
  completed_lessons = EXCLUDED.completed_lessons,
  last_study_date = GREATEST(user_progress.last_study_date, EXCLUDED.last_study_date);

-- 7. Remover registros antigos duplicados (manter apenas o consolidado)
DELETE FROM user_progress
WHERE id NOT IN (
  SELECT MIN(id)
  FROM user_progress
  GROUP BY user_id
);

-- 8. Verificar estrutura final
SELECT 
  '✅ Estrutura atualizada da tabela user_progress:' as status;

SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- 9. Garantir permissões
GRANT SELECT, INSERT, UPDATE, DELETE ON user_progress TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE user_progress_id_seq TO authenticated;

-- 10. Confirmar mudanças
SELECT 
  '✅ Total de registros após migração:' as info,
  COUNT(*) as total
FROM user_progress;
