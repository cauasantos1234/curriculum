-- ============================================================================
-- LIMPAR PROGRESSO INCORRETO E RESETAR
-- ============================================================================
-- Este script limpa todos os registros de progresso incorretos
-- ============================================================================

-- 1. Ver progresso atual de todos os usuários
SELECT 'PROGRESSO ATUAL POR USUARIO:' as info;

SELECT 
  u.email,
  u.name,
  COUNT(DISTINCT up.lesson_id) as aulas_completadas,
  up.study_streak as sequencia_estudo,
  up.study_time_minutes as minutos_estudo
FROM users u
LEFT JOIN user_progress up ON up.user_id = u.id
GROUP BY u.id, u.email, u.name, up.study_streak, up.study_time_minutes
ORDER BY u.email;

-- 2. DELETAR TODOS OS PROGRESSOS (RESET COMPLETO)
-- Descomente apenas se quiser resetar TUDO
/*
DELETE FROM user_progress;
SELECT 'Todos os progressos foram deletados!' as resultado;
*/

-- 3. DELETAR progresso de um usuario especifico
-- antonio@gmail.com
DELETE FROM user_progress 
WHERE user_id IN (
  SELECT id FROM users WHERE email = 'antonio@gmail.com'
);
SELECT 'Progresso do usuario deletado!' as resultado;

-- 4. Ver detalhes do progresso
SELECT 'DETALHES DO PROGRESSO:' as info;

SELECT 
  u.email,
  up.completed_lessons as aulas_array,
  up.study_time_minutes as tempo_estudo,
  up.study_streak as sequencia,
  up.last_study_date as ultimo_estudo,
  up.achievements as conquistas
FROM users u
LEFT JOIN user_progress up ON up.user_id = u.id
ORDER BY u.email;

-- 5. CRIAR progresso vazio para todos os usuarios que nao tem
INSERT INTO user_progress (
  user_id,
  completed_lessons,
  study_time_minutes,
  study_streak,
  last_study_date,
  achievements,
  instrument_progress
)
SELECT 
  u.id,
  '{}',
  0,
  0,
  NULL,
  '{}',
  '{}'
FROM users u
WHERE NOT EXISTS (
  SELECT 1 FROM user_progress WHERE user_id = u.id
)
ON CONFLICT (user_id) DO NOTHING;

SELECT 'Progresso vazio criado para usuarios sem progresso' as resultado;

-- 6. Verificar resultado final
SELECT 'ESTATISTICAS FINAIS:' as info;

SELECT 
  (SELECT COUNT(*) FROM users) as total_usuarios,
  COUNT(DISTINCT up.user_id) as usuarios_com_progresso
FROM user_progress up;
