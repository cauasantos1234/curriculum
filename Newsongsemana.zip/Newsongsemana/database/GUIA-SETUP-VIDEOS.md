# 🎥 GUIA: Configurar Base de Dados de Vídeos

## 📋 O Que Este Setup Faz

Este script SQL configura a base de dados completa para que seus vídeos funcionem em **qualquer PC**, sincronizados via Supabase.

### ✨ Funcionalidades:
- ✅ Vídeos salvos na nuvem (Supabase)
- ✅ Sincronização automática entre PCs
- ✅ Acesso público aos vídeos (qualquer pessoa pode ver)
- ✅ Apenas usuários autenticados podem postar
- ✅ Sistema de visualizações e favoritos
- ✅ Performance otimizada com índices

---

## 🚀 OPÇÃO 1: Setup Automático (Recomendado)

1. **Abra o arquivo**: `test-videos-sync.html` no navegador
2. **Verifique** se está conectado ao Supabase
3. **Execute** os testes para diagnosticar problemas

---

## 🛠️ OPÇÃO 2: Setup Manual no Supabase

### Passo 1: Acessar o Supabase

1. Acesse: https://supabase.com/dashboard
2. Faça login
3. Selecione seu projeto: **wbzaktlcxgmctocgtifj**

### Passo 2: Executar o Script SQL

1. No menu lateral, clique em **"SQL Editor"**
2. Clique em **"New Query"**
3. Copie TODO o conteúdo do arquivo: `database/setup-videos-database.sql`
4. Cole no editor SQL
5. Clique em **"RUN"** (ou pressione Ctrl+Enter)

### Passo 3: Verificar Sucesso

Você deve ver mensagens como:
```
✅ Setup da base de dados de vídeos concluído!
📊 Estrutura criada
🔒 Políticas RLS configuradas
✨ Pronto para uso!
```

---

## 🔍 OPÇÃO 3: Verificar Tabelas Existentes

Se você não tem certeza se as tabelas já existem:

1. Vá para **"Table Editor"** no Supabase
2. Procure pela tabela **"videos"**
3. Se já existir, verifique se tem os campos:
   - `id`, `title`, `description`, `url`
   - `instrument`, `module`, `lesson`
   - `uploaded_by`, `teacher_email`
   - `views`, `likes`, `is_published`

---

## 🎯 Testando Após Setup

### Teste 1: Postar um Vídeo

1. Abra: `upload.html`
2. Faça login (se não estiver logado)
3. Preencha o formulário e poste um vídeo
4. Verifique no console do navegador (F12) se aparece:
   ```
   ✅ Vídeo salvo no Supabase!
   ```

### Teste 2: Ver Vídeos em Outro PC

1. Acesse o sistema em outro computador
2. Faça login com a mesma conta
3. Navegue até a página de vídeos
4. Os vídeos postados devem aparecer!

---

## 🔒 Políticas de Segurança (RLS)

### O que foi configurado:

1. **Visualização Pública** 📖
   - Qualquer pessoa pode VER vídeos publicados
   - Mesmo sem estar logado

2. **Inserção Protegida** ✍️
   - Apenas usuários AUTENTICADOS podem postar
   - Email do professor é salvo automaticamente

3. **Edição Restrita** ✏️
   - Professores só podem editar SEUS vídeos
   - Não podem editar vídeos de outros

4. **Exclusão Controlada** 🗑️
   - Professores só podem deletar SEUS vídeos

---

## ❓ Troubleshooting

### Problema: "Vídeos não aparecem em outro PC"

**Causa**: Vídeos estão salvos apenas localmente (localStorage)

**Solução**: 
1. Execute o script SQL acima
2. Reposte os vídeos para salvá-los no Supabase
3. Ou migre os vídeos locais para o Supabase

### Problema: "Erro ao salvar vídeo"

**Causa**: Usuário não está autenticado no Supabase

**Solução**:
1. Faça logout
2. Faça login novamente
3. Verifique se `localStorage.getItem('supabase.auth.token')` existe

### Problema: "Permission denied"

**Causa**: Políticas RLS não configuradas

**Solução**:
1. Execute o script SQL novamente
2. Verifique se RLS está habilitado:
   ```sql
   SELECT tablename, rowsecurity 
   FROM pg_tables 
   WHERE schemaname = 'public' 
   AND tablename = 'videos';
   ```

---

## 📊 Estrutura das Tabelas

### Tabela: `videos`
```sql
id              BIGINT (auto-incremento)
title           TEXT (obrigatório)
description     TEXT
url             TEXT (URL do YouTube ou null)
thumbnail_url   TEXT
instrument      TEXT (guitar, drums, etc)
module          TEXT (bronze, silver, gold)
lesson          TEXT (número da aula)
duration        TEXT (formato MM:SS)
uploaded_by     UUID (ID do usuário Supabase)
teacher_email   TEXT (email do professor)
views           INTEGER (contador)
likes           INTEGER (contador)
is_published    BOOLEAN (se está visível)
upload_type     TEXT (youtube ou file)
created_at      TIMESTAMPTZ
updated_at      TIMESTAMPTZ
```

### Tabela: `video_views`
```sql
id          BIGINT
video_id    BIGINT (FK para videos)
user_id     UUID (FK para auth.users)
viewed_at   TIMESTAMPTZ
```

### Tabela: `saved_videos`
```sql
id          BIGINT
user_id     UUID (FK para auth.users)
video_id    BIGINT (FK para videos)
saved_at    TIMESTAMPTZ
```

---

## 🎓 Próximos Passos

Após executar o setup:

1. ✅ Execute o script SQL
2. ✅ Teste postando um vídeo
3. ✅ Verifique em outro PC
4. ✅ Configure backup automático (opcional)

---

## 💡 Dicas

- **Backup**: Os vídeos ficam salvos no Supabase, mas faça backup regular
- **Performance**: Os índices já estão criados para busca rápida
- **Segurança**: Apenas o dono pode editar/deletar seus vídeos
- **Escalabilidade**: Suporta milhares de vídeos sem problemas

---

**Feito! Seus vídeos agora funcionam em qualquer PC! 🎉**
