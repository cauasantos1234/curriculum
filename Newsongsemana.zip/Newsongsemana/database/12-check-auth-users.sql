-- ============================================
-- VERIFICAR USUÁRIOS NO SUPABASE AUTH
-- ============================================

-- 1. Contar usuários no Auth
SELECT COUNT(*) as "Total de usuários Auth" FROM auth.users;

-- 2. Listar todos os usuários do Auth
SELECT 
  id,
  email,
  created_at,
  last_sign_in_at,
  email_confirmed_at,
  confirmation_sent_at,
  raw_user_meta_data
FROM auth.users
ORDER BY created_at DESC;

-- 3. Verificar se a função get_all_auth_users funciona
SELECT * FROM get_all_auth_users();
