-- ============================================================================
-- DIAGNÓSTICO COMPLETO - User Progress
-- ============================================================================
-- Use este script para diagnosticar todos os problemas com user_progress
-- ============================================================================

-- 1. Verificar se a tabela existe
SELECT 
  'user_progress' as tabela,
  CASE WHEN EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'user_progress')
    THEN '✅ Existe'
    ELSE '❌ NÃO EXISTE - Execute 01-complete-schema.sql'
  END as status;

-- 2. Verificar estrutura da tabela
SELECT 
  '📋 Colunas da tabela user_progress:' as info;

SELECT 
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- 3. Verificar políticas RLS
SELECT 
  '🔒 Políticas RLS ativas:' as info;

SELECT 
  policyname,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'user_progress';

-- 4. Verificar se RLS está habilitado
SELECT 
  tablename,
  rowsecurity as rls_habilitado
FROM pg_tables
WHERE tablename = 'user_progress';

-- 5. Contar registros existentes
SELECT 
  '📊 Total de registros:' as info,
  COUNT(*) as total
FROM user_progress;

-- 6. Verificar registros por usuário
SELECT 
  '👥 Registros por usuário:' as info;

SELECT 
  u.email,
  u.name,
  COUNT(up.id) as total_progress
FROM users u
LEFT JOIN user_progress up ON up.user_id = u.id
GROUP BY u.id, u.email, u.name
ORDER BY total_progress DESC;

-- 7. Verificar permissões
SELECT 
  '🔑 Permissões na tabela:' as info;

SELECT 
  grantee,
  privilege_type
FROM information_schema.role_table_grants
WHERE table_name = 'user_progress'
AND grantee != 'postgres';

-- 8. Testar inserção de progresso (teste)
-- Descomente para testar:
/*
INSERT INTO user_progress (user_id, lesson_id, completed, progress_percentage)
SELECT 
  u.id,
  1, -- lesson_id
  false,
  0
FROM users u
WHERE u.email = 'SEU_EMAIL_AQUI@gmail.com'
LIMIT 1
ON CONFLICT (user_id, lesson_id) DO UPDATE
SET last_accessed = NOW();
*/

-- 9. Verificar se há erros de constraint
SELECT 
  '⚠️ Constraints:' as info;

SELECT 
  conname as constraint_name,
  contype as constraint_type,
  pg_get_constraintdef(oid) as definition
FROM pg_constraint
WHERE conrelid = 'user_progress'::regclass;

-- 10. Verificar índices
SELECT 
  '📇 Índices:' as info;

SELECT 
  indexname,
  indexdef
FROM pg_indexes
WHERE tablename = 'user_progress';
