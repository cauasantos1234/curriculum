-- =====================================================
-- VERIFICAR XP DO USUÁRIO - Script de Diagnóstico
-- Execute este script no Supabase SQL Editor
-- =====================================================

-- 1. VERIFICAR USUÁRIOS REGISTRADOS
SELECT 
  id,
  email,
  created_at,
  (SELECT total_xp FROM user_xp WHERE user_id = auth.users.id) as xp_atual,
  (SELECT level FROM user_xp WHERE user_id = auth.users.id) as nivel_atual,
  (SELECT current_streak FROM user_xp WHERE user_id = auth.users.id) as streak_atual
FROM auth.users
ORDER BY created_at DESC
LIMIT 10;

-- 2. VERIFICAR REGISTROS DE XP
SELECT 
  ux.user_id,
  u.email,
  ux.total_xp,
  ux.level,
  ux.current_streak,
  ux.last_activity_date,
  ux.updated_at
FROM user_xp ux
JOIN auth.users u ON u.id = ux.user_id
ORDER BY ux.total_xp DESC;

-- 3. VERIFICAR TRANSAÇÕES DE XP RECENTES
SELECT 
  t.id,
  u.email,
  t.xp_amount,
  t.action_type,
  t.description,
  t.created_at
FROM xp_transactions t
JOIN auth.users u ON u.id = t.user_id
ORDER BY t.created_at DESC
LIMIT 20;

-- 4. VERIFICAR SE FUNÇÃO add_xp_to_user EXISTE
SELECT 
  routine_name,
  routine_type,
  data_type
FROM information_schema.routines
WHERE routine_name = 'add_xp_to_user';

-- 5. VERIFICAR RANKING ATUAL
SELECT * FROM ranking_by_xp LIMIT 10;

-- 6. TESTAR ADIÇÃO DE XP MANUALMENTE (SUBSTITUA O UUID PELO SEU)
-- DESCOMENTE E SUBSTITUA '<SEU-USER-ID>' PELO UUID DO SEU USUÁRIO
-- SELECT add_xp_to_user(
--   '<SEU-USER-ID>'::UUID,
--   50,
--   'teste_manual',
--   NULL,
--   'Teste de adição de XP'
-- );

-- 7. VERIFICAR POLÍTICAS RLS DA TABELA user_xp
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd
FROM pg_policies
WHERE tablename = 'user_xp';

-- 8. VERIFICAR SE HÁ ERROS DE PERMISSÃO
-- Verificar grants na função
SELECT 
  routine_schema,
  routine_name,
  grantee,
  privilege_type
FROM information_schema.routine_privileges
WHERE routine_name = 'add_xp_to_user';
