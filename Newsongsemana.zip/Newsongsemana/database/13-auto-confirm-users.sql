-- ============================================
-- AUTO-CONFIRMAR TODOS OS USUÁRIOS
-- Execute este script no SQL Editor do Supabase
-- ============================================

-- 1. Confirmar todos os usuários existentes que ainda não foram confirmados
-- ATENÇÃO: Este comando requer privilégios de service_role
-- Execute diretamente no SQL Editor do Supabase Dashboard

-- Ver usuários não confirmados
SELECT 
  id,
  email,
  email_confirmed_at,
  created_at
FROM auth.users
WHERE email_confirmed_at IS NULL;

-- Para confirmar manualmente cada usuário, use este UPDATE:
-- Substitua 'EMAIL_DO_USUARIO' pelo email real

-- UPDATE auth.users 
-- SET email_confirmed_at = NOW(), 
--     confirmed_at = NOW()
-- WHERE email = 'igorguedes@gmail.com';

-- UPDATE auth.users 
-- SET email_confirmed_at = NOW(), 
--     confirmed_at = NOW()
-- WHERE email = 'a101442@epinfante.com';

-- ============================================
-- ALTERNATIVA: Confirmar TODOS os usuários de uma vez
-- ============================================

-- CUIDADO: Isso confirmará TODOS os usuários não confirmados
UPDATE auth.users 
SET 
  email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
  confirmed_at = COALESCE(confirmed_at, NOW())
WHERE email_confirmed_at IS NULL;

-- Verificar resultado
SELECT 
  email,
  email_confirmed_at,
  'Confirmado!' as status
FROM auth.users
ORDER BY created_at DESC;
