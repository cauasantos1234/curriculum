-- ========================================
-- FUNÇÃO DE SINCRONIZAÇÃO AUTH → USERS
-- ========================================
-- Esta função sincroniza todos os usuários de auth.users
-- para a tabela users customizada
--
-- Execute este SQL no SQL Editor do Supabase

CREATE OR REPLACE FUNCTION sync_auth_to_users()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result_count integer := 0;
  auth_user record;
BEGIN
  FOR auth_user IN 
    SELECT id, email, raw_user_meta_data, created_at
    FROM auth.users
  LOOP
    INSERT INTO users (id, email, name, role, created_at, is_active)
    VALUES (
      auth_user.id,
      auth_user.email,
      COALESCE(auth_user.raw_user_meta_data->>'name', split_part(auth_user.email, '@', 1)),
      COALESCE(auth_user.raw_user_meta_data->>'role', 'student'),
      auth_user.created_at,
      true
    )
    ON CONFLICT (id) DO UPDATE
    SET 
      email = EXCLUDED.email,
      name = COALESCE(EXCLUDED.name, users.name),
      role = COALESCE(EXCLUDED.role, users.role);
    
    result_count := result_count + 1;
  END LOOP;
  
  RETURN json_build_object('synchronized', result_count);
END;
$$;

-- Dar permissões
GRANT EXECUTE ON FUNCTION sync_auth_to_users() TO authenticated, anon;

-- Testar a função
SELECT sync_auth_to_users();
