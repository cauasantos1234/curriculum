-- ========================================
-- SETUP COMPLETO PAINEL ADMIN SUPABASE
-- ========================================
-- Execute este arquivo COMPLETO no SQL Editor do Supabase
-- para habilitar todas as funcionalidades do painel admin
--
-- Criado em: 21/01/2026

-- ========================================
-- 1. FUNÇÃO PARA BUSCAR TODOS USUÁRIOS AUTH
-- ========================================

CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz,
  last_sign_in_at timestamptz,
  email_confirmed_at timestamptz,
  role text
) 
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY 
  SELECT 
    au.id,
    au.email,
    au.created_at,
    au.last_sign_in_at,
    au.email_confirmed_at,
    au.raw_user_meta_data->>'role' as role
  FROM auth.users au
  ORDER BY au.created_at DESC;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION get_all_auth_users() TO anon, authenticated;

-- ========================================
-- 2. FUNÇÃO DE SINCRONIZAÇÃO AUTH → USERS
-- ========================================

CREATE OR REPLACE FUNCTION sync_auth_to_users()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  result_count integer := 0;
  auth_user record;
BEGIN
  FOR auth_user IN 
    SELECT id, email, raw_user_meta_data, created_at
    FROM auth.users
  LOOP
    INSERT INTO users (id, email, name, role, created_at, is_active)
    VALUES (
      auth_user.id,
      auth_user.email,
      COALESCE(auth_user.raw_user_meta_data->>'name', split_part(auth_user.email, '@', 1)),
      COALESCE(auth_user.raw_user_meta_data->>'role', 'student'),
      auth_user.created_at,
      true
    )
    ON CONFLICT (id) DO UPDATE
    SET 
      email = EXCLUDED.email,
      name = COALESCE(EXCLUDED.name, users.name),
      role = COALESCE(EXCLUDED.role, users.role),
      updated_at = now();
    
    result_count := result_count + 1;
  END LOOP;
  
  RETURN json_build_object(
    'success', true,
    'synchronized', result_count,
    'message', format('%s usuários sincronizados com sucesso', result_count)
  );
END;
$$;

GRANT EXECUTE ON FUNCTION sync_auth_to_users() TO authenticated, anon;

-- ========================================
-- 3. POLÍTICAS RLS PARA ADMIN
-- ========================================

-- Permitir leitura da tabela users (necessário para o painel)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Allow read users for admin'
  ) THEN
    CREATE POLICY "Allow read users for admin" 
    ON users FOR SELECT 
    USING (true);
  END IF;
END $$;

-- ========================================
-- 4. FUNÇÃO DE ESTATÍSTICAS
-- ========================================

CREATE OR REPLACE FUNCTION get_system_stats()
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  total_users integer;
  total_videos integer;
  total_xp bigint;
  total_progress integer;
  total_views integer;
  total_ratings integer;
BEGIN
  -- Contar usuários
  SELECT COUNT(*) INTO total_users FROM users;
  
  -- Contar vídeos
  SELECT COUNT(*) INTO total_videos FROM videos;
  
  -- Somar XP
  SELECT COALESCE(SUM(xp_amount), 0) INTO total_xp FROM user_xp;
  
  -- Contar progresso
  SELECT COUNT(*) INTO total_progress FROM user_progress;
  
  -- Contar visualizações
  SELECT COUNT(*) INTO total_views FROM video_views;
  
  -- Contar avaliações
  SELECT COUNT(*) INTO total_ratings FROM video_ratings;
  
  RETURN json_build_object(
    'users', total_users,
    'videos', total_videos,
    'xp', total_xp,
    'progress', total_progress,
    'views', total_views,
    'ratings', total_ratings,
    'timestamp', now()
  );
END;
$$;

GRANT EXECUTE ON FUNCTION get_system_stats() TO authenticated, anon;

-- ========================================
-- 5. TESTAR FUNÇÕES
-- ========================================

-- Testar busca de usuários auth
SELECT 'Teste get_all_auth_users:' as teste;
SELECT COUNT(*) as total_auth_users FROM get_all_auth_users();

-- Testar sincronização
SELECT 'Teste sync_auth_to_users:' as teste;
SELECT sync_auth_to_users();

-- Testar estatísticas
SELECT 'Teste get_system_stats:' as teste;
SELECT get_system_stats();

-- ========================================
-- 6. VERIFICAÇÃO FINAL
-- ========================================

SELECT 
  'Setup completo!' as status,
  (SELECT COUNT(*) FROM auth.users) as usuarios_auth,
  (SELECT COUNT(*) FROM users) as usuarios_tabela,
  (SELECT COUNT(*) FROM videos) as total_videos,
  now() as executado_em;

-- ========================================
-- SUCESSO! 
-- ========================================
-- Agora você pode usar todas as funcionalidades
-- do painel admin em supabase-admin.html
--
-- Funcionalidades habilitadas:
-- ✅ Ver todos os usuários do auth
-- ✅ Sincronizar auth → users
-- ✅ Estatísticas do sistema
-- ✅ Políticas RLS configuradas
-- ========================================
