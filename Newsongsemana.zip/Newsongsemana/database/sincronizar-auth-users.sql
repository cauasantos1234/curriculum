-- ============================================================================
-- SINCRONIZAR AUTH.USERS COM TABELA USERS
-- ============================================================================
-- Este script mostra contas criadas (auth.users) vs contas que fizeram login (users)
-- ============================================================================

-- 1. Ver todas as contas criadas no auth.users
SELECT 
  '📧 CONTAS CRIADAS (auth.users):' as info;

SELECT 
  email,
  created_at as criado_em,
  last_sign_in_at as ultimo_login,
  raw_user_meta_data->>'name' as nome,
  raw_user_meta_data->>'role' as tipo,
  CASE 
    WHEN last_sign_in_at IS NULL THEN '❌ NUNCA FEZ LOGIN'
    ELSE '✅ Já fez login'
  END as status
FROM auth.users
ORDER BY created_at DESC;

-- 2. Ver usuários na tabela 'users' (só quem já fez login)
SELECT 
  '👥 USUÁRIOS NA TABELA USERS (só quem já logou):' as info;

SELECT 
  name as nome,
  email,
  role as tipo,
  created_at as criado_em
FROM users
ORDER BY created_at DESC;

-- 3. SINCRONIZAR: Adicionar contas do auth.users que ainda não estão em 'users'
SELECT 
  '🔄 SINCRONIZANDO CONTAS...' as info;

INSERT INTO users (
  id,
  email,
  name,
  password_hash,
  created_at,
  is_active,
  role
)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', SPLIT_PART(au.email, '@', 1)),
  'FROM_AUTH_USERS',
  au.created_at,
  true,
  COALESCE(au.raw_user_meta_data->>'role', 'student')
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
WHERE u.id IS NULL
ON CONFLICT (id) DO UPDATE
SET 
  email = EXCLUDED.email,
  name = EXCLUDED.name,
  role = EXCLUDED.role;

-- 4. Verificar resultado
SELECT 
  '✅ SINCRONIZAÇÃO CONCLUÍDA!' as resultado;

SELECT 
  '📊 Total de contas criadas (auth.users):' as metrica,
  COUNT(*)::text as valor
FROM auth.users
UNION ALL
SELECT 
  '👥 Total de usuários sincronizados (users):',
  COUNT(*)::text
FROM users
UNION ALL
SELECT 
  '🔗 Usuários com login ativo:',
  COUNT(*)::text
FROM auth.users
WHERE last_sign_in_at IS NOT NULL;

-- 5. Detalhes de cada conta
SELECT 
  '🔍 DETALHES DAS CONTAS:' as info;

SELECT 
  u.email,
  u.name,
  u.role as tipo,
  CASE 
    WHEN au.last_sign_in_at IS NULL THEN '❌ Nunca fez login'
    WHEN au.last_sign_in_at < NOW() - INTERVAL '7 days' THEN '⚠️ Inativo há 7+ dias'
    ELSE '✅ Ativo recentemente'
  END as status_login,
  au.created_at as conta_criada_em,
  au.last_sign_in_at as ultimo_login
FROM users u
INNER JOIN auth.users au ON u.id = au.id
ORDER BY au.created_at DESC;
