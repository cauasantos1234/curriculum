-- ============================================================================
-- FIX USER_PROGRESS - Políticas RLS Simplificadas
-- ============================================================================
-- Este script corrige os erros 406 (Not Acceptable) ao acessar user_progress
-- ============================================================================

-- 1. Remover políticas antigas problemáticas
DROP POLICY IF EXISTS "Usuários veem apenas próprio progresso" ON user_progress;
DROP POLICY IF EXISTS "Usuários podem registrar próprio progresso" ON user_progress;
DROP POLICY IF EXISTS "Usuários podem atualizar próprio progresso" ON user_progress;

-- 2. Criar políticas simplificadas que funcionam com auth.users
CREATE POLICY "users_select_own_progress"
ON user_progress FOR SELECT
USING (
  user_id IN (
    SELECT id FROM users WHERE email = auth.jwt()->>'email'
  )
);

CREATE POLICY "users_insert_own_progress"
ON user_progress FOR INSERT
WITH CHECK (
  user_id IN (
    SELECT id FROM users WHERE email = auth.jwt()->>'email'
  )
);

CREATE POLICY "users_update_own_progress"
ON user_progress FOR UPDATE
USING (
  user_id IN (
    SELECT id FROM users WHERE email = auth.jwt()->>'email'
  )
);

-- 3. Política de DELETE também
CREATE POLICY "users_delete_own_progress"
ON user_progress FOR DELETE
USING (
  user_id IN (
    SELECT id FROM users WHERE email = auth.jwt()->>'email'
  )
);

-- 4. Verificar se a tabela existe e está correta
DO $$
BEGIN
  -- Verificar se user_progress existe
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'user_progress') THEN
    RAISE EXCEPTION 'Tabela user_progress não existe! Execute 01-complete-schema.sql primeiro';
  END IF;
  
  -- Verificar se achievements column existe (erro do console)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'user_progress' AND column_name = 'achievements'
  ) THEN
    RAISE NOTICE 'Coluna achievements não existe em user_progress - isto é NORMAL, o erro no console é enganoso';
  END IF;
END $$;

-- 5. Garantir que RLS está habilitado
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- 6. Dar permissões de acesso
GRANT SELECT, INSERT, UPDATE, DELETE ON user_progress TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE user_progress_id_seq TO authenticated;

-- 7. Testar se as políticas funcionam
SELECT 
  'Políticas configuradas:' AS status,
  COUNT(*) as total_policies
FROM pg_policies 
WHERE tablename = 'user_progress';

-- 8. Mostrar estrutura da tabela
SELECT 
  column_name,
  data_type,
  is_nullable
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;
