-- ============================================================================
-- FIX FINAL - Desabilitar RLS temporariamente para testes
-- ============================================================================
-- Este é um fix TEMPORÁRIO para garantir que o sistema funcione
-- ATENÇÃO: Em produção, você deve reabilitar RLS com políticas corretas
-- ============================================================================

-- 1. DESABILITAR RLS em user_progress (temporário para testes)
ALTER TABLE user_progress DISABLE ROW LEVEL SECURITY;

-- 2. DESABILITAR RLS em users (temporário para testes)
ALTER TABLE users DISABLE ROW LEVEL SECURITY;

-- 3. Garantir permissões totais
GRANT ALL ON user_progress TO authenticated;
GRANT ALL ON users TO authenticated;

-- 4. Verificar status
SELECT 
  '⚠️ RLS DESABILITADO TEMPORARIAMENTE!' as status,
  'Isso é apenas para TESTES - funciona mas não é seguro' as aviso;

SELECT 
  tablename,
  rowsecurity as rls_habilitado
FROM pg_tables
WHERE tablename IN ('users', 'user_progress');

-- 5. Limpar cache de políticas
DO $$
BEGIN
  -- Forçar atualização de cache do Supabase
  PERFORM pg_notify('pgrst', 'reload schema');
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

SELECT 
  '✅ Agora DEVE funcionar!' as resultado,
  'Atualize o navegador com Ctrl+F5' as proxima_acao;
