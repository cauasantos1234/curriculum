-- ============================================
-- CONFIGURAR SINCRONIZAÇÃO DE PROGRESSO
-- Execute este script no SQL Editor do Supabase
-- ============================================

-- 1. Ajustar estrutura da tabela user_progress para armazenar dados completos
DROP TABLE IF EXISTS user_progress CASCADE;

CREATE TABLE user_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  
  -- Dados de progresso
  completed_lessons INTEGER[] DEFAULT '{}',
  study_time_minutes INTEGER DEFAULT 0,
  study_streak INTEGER DEFAULT 0,
  last_study_date TIMESTAMPTZ,
  
  -- Conquistas e progresso por instrumento
  achievements TEXT[] DEFAULT '{}',
  instrument_progress JSONB DEFAULT '{}',
  
  -- Metadados
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  CONSTRAINT positive_study_time CHECK (study_time_minutes >= 0),
  CONSTRAINT positive_streak CHECK (study_streak >= 0)
);

-- Índices
CREATE INDEX idx_user_progress_user_id ON user_progress(user_id);
CREATE INDEX idx_user_progress_updated ON user_progress(updated_at DESC);

-- 2. Habilitar RLS
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- 3. Políticas de segurança

-- Usuários podem ler seu próprio progresso
DROP POLICY IF EXISTS "Users can read own progress" ON user_progress;
CREATE POLICY "Users can read own progress" 
  ON user_progress 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Usuários podem inserir seu próprio progresso
DROP POLICY IF EXISTS "Users can insert own progress" ON user_progress;
CREATE POLICY "Users can insert own progress" 
  ON user_progress 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Usuários podem atualizar seu próprio progresso
DROP POLICY IF EXISTS "Users can update own progress" ON user_progress;
CREATE POLICY "Users can update own progress" 
  ON user_progress 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- 4. Função para atualizar timestamp automaticamente
CREATE OR REPLACE FUNCTION update_progress_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_progress_timestamp ON user_progress;
CREATE TRIGGER trigger_update_progress_timestamp
  BEFORE UPDATE ON user_progress
  FOR EACH ROW
  EXECUTE FUNCTION update_progress_timestamp();

-- 5. Verificar estrutura
SELECT 
  column_name, 
  data_type, 
  is_nullable
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- 6. Criar função para obter progresso do usuário
CREATE OR REPLACE FUNCTION get_user_progress(p_user_id UUID)
RETURNS TABLE (
  completed_lessons INTEGER[],
  study_time_minutes INTEGER,
  study_streak INTEGER,
  last_study_date TIMESTAMPTZ,
  achievements TEXT[],
  instrument_progress JSONB,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    up.completed_lessons,
    up.study_time_minutes,
    up.study_streak,
    up.last_study_date,
    up.achievements,
    up.instrument_progress,
    up.created_at,
    up.updated_at
  FROM user_progress up
  WHERE up.user_id = p_user_id;
END;
$$;

-- 7. Criar função para salvar progresso (upsert)
CREATE OR REPLACE FUNCTION save_user_progress(
  p_user_id UUID,
  p_completed_lessons INTEGER[],
  p_study_time_minutes INTEGER,
  p_study_streak INTEGER,
  p_last_study_date TIMESTAMPTZ,
  p_achievements TEXT[],
  p_instrument_progress JSONB
)
RETURNS user_progress
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_result user_progress;
BEGIN
  INSERT INTO user_progress (
    user_id,
    completed_lessons,
    study_time_minutes,
    study_streak,
    last_study_date,
    achievements,
    instrument_progress
  ) VALUES (
    p_user_id,
    p_completed_lessons,
    p_study_time_minutes,
    p_study_streak,
    p_last_study_date,
    p_achievements,
    p_instrument_progress
  )
  ON CONFLICT (user_id) DO UPDATE SET
    completed_lessons = EXCLUDED.completed_lessons,
    study_time_minutes = EXCLUDED.study_time_minutes,
    study_streak = EXCLUDED.study_streak,
    last_study_date = EXCLUDED.last_study_date,
    achievements = EXCLUDED.achievements,
    instrument_progress = EXCLUDED.instrument_progress,
    updated_at = NOW()
  RETURNING * INTO v_result;
  
  RETURN v_result;
END;
$$;

-- 8. Testar
SELECT 'Setup de user_progress concluído! ✅' as status;
