-- ========================================
-- FUNÇÃO PARA VER TODOS OS USUÁRIOS DO AUTH
-- ========================================
-- Esta função permite que o painel admin veja TODAS as contas criadas,
-- incluindo aquelas que nunca fizeram login
--
-- Execute este SQL no SQL Editor do Supabase

-- Criar função para buscar todos os usuários do auth
CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz,
  last_sign_in_at timestamptz,
  email_confirmed_at timestamptz,
  role text
) 
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY 
  SELECT 
    au.id,
    au.email,
    au.created_at,
    au.last_sign_in_at,
    au.email_confirmed_at,
    au.raw_user_meta_data->>'role' as role
  FROM auth.users au
  ORDER BY au.created_at DESC;
END;
$$ LANGUAGE plpgsql;

-- Dar permissões para todos (anon e authenticated)
GRANT EXECUTE ON FUNCTION get_all_auth_users() TO anon, authenticated;

-- Testar a função
SELECT * FROM get_all_auth_users();
