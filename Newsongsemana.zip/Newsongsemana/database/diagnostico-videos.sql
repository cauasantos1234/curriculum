-- =====================================================
-- DIAGNÓSTICO DE VÍDEOS - Verificar vídeos que sumiram
-- Execute este script no Supabase SQL Editor
-- =====================================================

-- 1. VERIFICAR TOTAL DE VÍDEOS (incluindo não publicados)
SELECT 
  COUNT(*) as total_videos,
  COUNT(CASE WHEN is_published = true THEN 1 END) as videos_publicados,
  COUNT(CASE WHEN is_published = false OR is_published IS NULL THEN 1 END) as videos_nao_publicados
FROM videos;

-- 2. VER TODOS OS VÍDEOS (incluindo não publicados)
SELECT 
  id,
  title,
  instrument,
  module,
  uploaded_by_name,
  teacher_email,
  is_published,
  created_at,
  views,
  likes
FROM videos
ORDER BY created_at DESC
LIMIT 50;

-- 3. VER APENAS VÍDEOS NÃO PUBLICADOS (podem ter sumido)
SELECT 
  id,
  title,
  instrument,
  module,
  uploaded_by_name,
  teacher_email,
  is_published,
  created_at
FROM videos
WHERE is_published = false OR is_published IS NULL
ORDER BY created_at DESC;

-- 4. VERIFICAR VÍDEOS ADICIONADOS NAS ÚLTIMAS 24 HORAS
SELECT 
  id,
  title,
  instrument,
  module,
  uploaded_by_name,
  is_published,
  created_at
FROM videos
WHERE created_at > NOW() - INTERVAL '24 hours'
ORDER BY created_at DESC;

-- 5. REPUBLICAR TODOS OS VÍDEOS (caso queira tornar todos visíveis)
-- DESCOMENTE A LINHA ABAIXO PARA EXECUTAR
-- UPDATE videos SET is_published = true WHERE is_published = false OR is_published IS NULL;

-- 6. REPUBLICAR UM VÍDEO ESPECÍFICO PELO ID
-- DESCOMENTE E SUBSTITUA <ID> PELO ID DO VÍDEO
-- UPDATE videos SET is_published = true WHERE id = <ID>;

-- 7. VERIFICAR SE HÁ PROBLEMAS COM POLÍTICAS RLS
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies
WHERE tablename = 'videos';
