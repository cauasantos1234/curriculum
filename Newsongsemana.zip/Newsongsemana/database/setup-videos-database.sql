-- =====================================================
-- SETUP COMPLETO DA BASE DE DADOS DE VÍDEOS
-- Execute este script no Supabase SQL Editor
-- =====================================================

-- 1. CRIAR TABELA DE VÍDEOS (se não existir)
CREATE TABLE IF NOT EXISTS videos (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  url TEXT,
  thumbnail_url TEXT,
  instrument TEXT NOT NULL,
  module TEXT NOT NULL,
  lesson TEXT,
  lesson_id INTEGER,
  duration TEXT DEFAULT '0:00',
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  uploaded_by_name TEXT,
  teacher_email TEXT,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  upload_type TEXT DEFAULT 'youtube',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 1.1 ADICIONAR COLUNAS FALTANTES (se a tabela já existir)
DO $$ 
BEGIN
  -- Adicionar coluna instrument se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='instrument') THEN
    ALTER TABLE videos ADD COLUMN instrument TEXT NOT NULL DEFAULT 'guitar';
    RAISE NOTICE 'Coluna instrument adicionada';
  END IF;
  
  -- Adicionar coluna module se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='module') THEN
    ALTER TABLE videos ADD COLUMN module TEXT NOT NULL DEFAULT 'bronze';
    RAISE NOTICE 'Coluna module adicionada';
  END IF;
  
  -- Adicionar coluna lesson se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='lesson') THEN
    ALTER TABLE videos ADD COLUMN lesson TEXT;
    RAISE NOTICE 'Coluna lesson adicionada';
  END IF;
  
  -- Adicionar coluna lesson_id se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='lesson_id') THEN
    ALTER TABLE videos ADD COLUMN lesson_id INTEGER;
    RAISE NOTICE 'Coluna lesson_id adicionada';
  END IF;
  
  -- Adicionar coluna uploaded_by_name se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='uploaded_by_name') THEN
    ALTER TABLE videos ADD COLUMN uploaded_by_name TEXT;
    RAISE NOTICE 'Coluna uploaded_by_name adicionada';
  END IF;
  
  -- Adicionar coluna teacher_email se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='teacher_email') THEN
    ALTER TABLE videos ADD COLUMN teacher_email TEXT;
    RAISE NOTICE 'Coluna teacher_email adicionada';
  END IF;
  
  -- Adicionar coluna upload_type se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='upload_type') THEN
    ALTER TABLE videos ADD COLUMN upload_type TEXT DEFAULT 'youtube';
    RAISE NOTICE 'Coluna upload_type adicionada';
  END IF;
  
  -- Adicionar coluna is_published se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='is_published') THEN
    ALTER TABLE videos ADD COLUMN is_published BOOLEAN DEFAULT true;
    RAISE NOTICE 'Coluna is_published adicionada';
  END IF;
  
  -- Adicionar coluna views se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='views') THEN
    ALTER TABLE videos ADD COLUMN views INTEGER DEFAULT 0;
    RAISE NOTICE 'Coluna views adicionada';
  END IF;
  
  -- Adicionar coluna likes se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='likes') THEN
    ALTER TABLE videos ADD COLUMN likes INTEGER DEFAULT 0;
    RAISE NOTICE 'Coluna likes adicionada';
  END IF;
  
  -- Adicionar coluna duration se não existir
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='videos' AND column_name='duration') THEN
    ALTER TABLE videos ADD COLUMN duration TEXT DEFAULT '0:00';
    RAISE NOTICE 'Coluna duration adicionada';
  END IF;
  
  RAISE NOTICE '✅ Estrutura da tabela videos atualizada';
END $$;

-- 2. CRIAR ÍNDICES PARA PERFORMANCE
CREATE INDEX IF NOT EXISTS idx_videos_instrument ON videos(instrument);
CREATE INDEX IF NOT EXISTS idx_videos_module ON videos(module);
CREATE INDEX IF NOT EXISTS idx_videos_lesson ON videos(lesson);
CREATE INDEX IF NOT EXISTS idx_videos_uploaded_by ON videos(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_videos_teacher_email ON videos(teacher_email);
CREATE INDEX IF NOT EXISTS idx_videos_created_at ON videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_videos_published ON videos(is_published);

-- 3. CRIAR TRIGGER PARA ATUALIZAR updated_at
CREATE OR REPLACE FUNCTION update_videos_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_videos_updated_at ON videos;
CREATE TRIGGER trigger_update_videos_updated_at
  BEFORE UPDATE ON videos
  FOR EACH ROW
  EXECUTE FUNCTION update_videos_updated_at();

-- 4. HABILITAR RLS (Row Level Security)
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- 5. REMOVER POLÍTICAS ANTIGAS (se existirem)
DROP POLICY IF EXISTS "Todos podem ver vídeos publicados" ON videos;
DROP POLICY IF EXISTS "Professores podem inserir vídeos" ON videos;
DROP POLICY IF EXISTS "Professores podem editar seus vídeos" ON videos;
DROP POLICY IF EXISTS "Professores podem deletar seus vídeos" ON videos;
DROP POLICY IF EXISTS "Usuários autenticados podem ver vídeos" ON videos;
DROP POLICY IF EXISTS "Qualquer um pode ver vídeos publicados" ON videos;
DROP POLICY IF EXISTS "Usuários autenticados podem inserir vídeos" ON videos;
DROP POLICY IF EXISTS "Usuários podem editar seus vídeos" ON videos;
DROP POLICY IF EXISTS "Usuários podem deletar seus vídeos" ON videos;

-- 6. CRIAR POLÍTICAS DE ACESSO PÚBLICAS (IMPORTANTE!)

-- Política 1: QUALQUER PESSOA pode VER vídeos publicados (mesmo sem autenticação)
CREATE POLICY "Qualquer um pode ver vídeos publicados"
ON videos
FOR SELECT
TO anon, authenticated
USING (is_published = true);

-- Política 2: Usuários AUTENTICADOS podem INSERIR vídeos
CREATE POLICY "Usuários autenticados podem inserir vídeos"
ON videos
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Política 3: Professores podem EDITAR seus próprios vídeos
CREATE POLICY "Usuários podem editar seus vídeos"
ON videos
FOR UPDATE
TO authenticated
USING (uploaded_by = auth.uid())
WITH CHECK (uploaded_by = auth.uid());

-- Política 4: Professores podem DELETAR seus próprios vídeos
CREATE POLICY "Usuários podem deletar seus vídeos"
ON videos
FOR DELETE
TO authenticated
USING (uploaded_by = auth.uid());

-- 7. CRIAR TABELA DE VISUALIZAÇÕES (se não existir)
CREATE TABLE IF NOT EXISTS video_views (
  id BIGSERIAL PRIMARY KEY,
  video_id BIGINT REFERENCES videos(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  viewed_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_video_views_video_id ON video_views(video_id);
CREATE INDEX IF NOT EXISTS idx_video_views_user_id ON video_views(user_id);

-- Habilitar RLS para video_views
ALTER TABLE video_views ENABLE ROW LEVEL SECURITY;

-- Políticas para video_views
DROP POLICY IF EXISTS "Qualquer um pode registrar visualização" ON video_views;
CREATE POLICY "Qualquer um pode registrar visualização"
ON video_views
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- 8. CRIAR FUNÇÃO PARA INCREMENTAR VIEWS
CREATE OR REPLACE FUNCTION increment_video_views(video_id BIGINT)
RETURNS void AS $$
BEGIN
  UPDATE videos
  SET views = views + 1
  WHERE id = video_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. CRIAR TABELA DE VÍDEOS SALVOS/FAVORITOS
CREATE TABLE IF NOT EXISTS saved_videos (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  video_id BIGINT REFERENCES videos(id) ON DELETE CASCADE,
  saved_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, video_id)
);

CREATE INDEX IF NOT EXISTS idx_saved_videos_user_id ON saved_videos(user_id);
CREATE INDEX IF NOT EXISTS idx_saved_videos_video_id ON saved_videos(video_id);

-- Habilitar RLS para saved_videos
ALTER TABLE saved_videos ENABLE ROW LEVEL SECURITY;

-- Políticas para saved_videos
DROP POLICY IF EXISTS "Usuários podem ver seus vídeos salvos" ON saved_videos;
DROP POLICY IF EXISTS "Usuários podem salvar vídeos" ON saved_videos;
DROP POLICY IF EXISTS "Usuários podem remover vídeos salvos" ON saved_videos;

CREATE POLICY "Usuários podem ver seus vídeos salvos"
ON saved_videos
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Usuários podem salvar vídeos"
ON saved_videos
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Usuários podem remover vídeos salvos"
ON saved_videos
FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- 10. CRIAR FUNÇÃO PARA BUSCAR VÍDEOS COM ESTATÍSTICAS
CREATE OR REPLACE FUNCTION get_videos_with_stats(
  p_instrument TEXT DEFAULT NULL,
  p_module TEXT DEFAULT NULL,
  p_lesson TEXT DEFAULT NULL
)
RETURNS TABLE (
  id BIGINT,
  title TEXT,
  description TEXT,
  url TEXT,
  thumbnail_url TEXT,
  instrument TEXT,
  module TEXT,
  lesson TEXT,
  lesson_id INTEGER,
  duration TEXT,
  uploaded_by_name TEXT,
  teacher_email TEXT,
  views INTEGER,
  likes INTEGER,
  upload_type TEXT,
  created_at TIMESTAMPTZ,
  is_saved BOOLEAN
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    v.id,
    v.title,
    v.description,
    v.url,
    v.thumbnail_url,
    v.instrument,
    v.module,
    v.lesson,
    v.lesson_id,
    v.duration,
    v.uploaded_by_name,
    v.teacher_email,
    v.views,
    v.likes,
    v.upload_type,
    v.created_at,
    EXISTS(
      SELECT 1 FROM saved_videos sv 
      WHERE sv.video_id = v.id 
      AND sv.user_id = auth.uid()
    ) as is_saved
  FROM videos v
  WHERE v.is_published = true
    AND (p_instrument IS NULL OR v.instrument = p_instrument)
    AND (p_module IS NULL OR v.module = p_module)
    AND (p_lesson IS NULL OR v.lesson = p_lesson)
  ORDER BY v.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. VERIFICAÇÃO FINAL
DO $$
BEGIN
  RAISE NOTICE '✅ Setup da base de dados de vídeos concluído!';
  RAISE NOTICE '';
  RAISE NOTICE '📊 Estrutura criada:';
  RAISE NOTICE '   - Tabela: videos';
  RAISE NOTICE '   - Tabela: video_views';
  RAISE NOTICE '   - Tabela: saved_videos';
  RAISE NOTICE '';
  RAISE NOTICE '🔒 Políticas RLS configuradas:';
  RAISE NOTICE '   - Vídeos públicos visíveis para todos';
  RAISE NOTICE '   - Usuários autenticados podem postar';
  RAISE NOTICE '   - Professores podem editar/deletar seus vídeos';
  RAISE NOTICE '';
  RAISE NOTICE '✨ Pronto para uso!';
END $$;

-- 12. CONSULTA DE TESTE (opcional - pode comentar se der erro)
DO $$
DECLARE
  v_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_count FROM videos;
  RAISE NOTICE '📊 Total de vídeos na tabela: %', v_count;
EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE '⚠️ Não foi possível contar vídeos (isso é normal em primeira execução)';
END $$;
