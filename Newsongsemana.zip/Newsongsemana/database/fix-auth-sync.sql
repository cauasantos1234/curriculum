-- ============================================================================
-- FIX AUTH SYNC - Sincronizar users com auth.users do Supabase
-- ============================================================================
-- Este script garante que os usuários na tabela 'users' estejam sincronizados
-- com a autenticação do Supabase (auth.users)
-- ============================================================================

-- DIAGNÓSTICO INICIAL
-- ----------------------------------------------------------------------------
SELECT '🔍 DIAGNÓSTICO DE AUTENTICAÇÃO:' as info;

-- 1. Verificar usuários em auth.users (tabela de autenticação do Supabase)
SELECT 
  '👥 Usuários em auth.users:' as tipo,
  COUNT(*) as total
FROM auth.users;

-- 2. Verificar usuários na tabela custom 'users'
SELECT 
  '📊 Usuários na tabela users:' as tipo,
  COUNT(*) as total
FROM users;

-- 3. Verificar se há diferenças
SELECT 
  '⚠️ Usuários em auth.users mas não em users:' as tipo,
  COUNT(*) as total
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
WHERE u.id IS NULL;

-- CORREÇÃO: Sincronizar tabelas
-- ----------------------------------------------------------------------------

-- 4. Inserir usuários de auth.users que não existem em users
INSERT INTO users (
  id,
  email,
  name,
  password_hash,
  created_at,
  is_active,
  role
)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', au.email),
  'SYNCED_FROM_AUTH', -- placeholder
  au.created_at,
  true,
  'student'
FROM auth.users au
LEFT JOIN users u ON u.id = au.id
WHERE u.id IS NULL
ON CONFLICT (id) DO NOTHING;

-- 5. Atualizar emails que podem estar diferentes
UPDATE users u
SET email = au.email
FROM auth.users au
WHERE u.id = au.id
AND u.email != au.email;

-- POLÍTICAS RLS PARA TABELA USERS
-- ----------------------------------------------------------------------------

-- 6. Garantir que RLS está habilitado em users
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- 7. Remover políticas antigas de users
DROP POLICY IF EXISTS "Usuários veem apenas próprio perfil" ON users;
DROP POLICY IF EXISTS "Usuários atualizam próprio perfil" ON users;
DROP POLICY IF EXISTS "allow_authenticated_users_select" ON users;
DROP POLICY IF EXISTS "allow_authenticated_users_update" ON users;

-- 8. Criar políticas permissivas para users
CREATE POLICY "allow_authenticated_users_select"
ON users FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "allow_authenticated_users_update"
ON users FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

-- 9. Conceder permissões
GRANT SELECT, UPDATE ON users TO authenticated;

-- VERIFICAÇÃO FINAL
-- ----------------------------------------------------------------------------
SELECT 
  '✅ SINCRONIZAÇÃO CONCLUÍDA!' as status,
  '' as detalhes
UNION ALL
SELECT 
  '👥 Total em auth.users:',
  COUNT(*)::text
FROM auth.users
UNION ALL
SELECT 
  '📊 Total em users:',
  COUNT(*)::text
FROM users
UNION ALL
SELECT 
  '🔗 Usuários sincronizados:',
  COUNT(*)::text
FROM users u
INNER JOIN auth.users au ON u.id = au.id;

-- 10. Mostrar detalhes dos usuários
SELECT 
  u.email,
  u.name,
  u.role,
  CASE 
    WHEN au.id IS NOT NULL THEN '✅ Autenticado'
    ELSE '❌ Sem autenticação'
  END as status_auth
FROM users u
LEFT JOIN auth.users au ON u.id = au.id
ORDER BY u.created_at DESC;
