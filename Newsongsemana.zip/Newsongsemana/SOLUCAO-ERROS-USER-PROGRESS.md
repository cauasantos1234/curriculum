# 🔧 SOLUÇÃO DOS ERROS 406, 403 e 400 - User Progress

## 🚨 PROBLEMAS IDENTIFICADOS

Os erros no console acontecem porque:

1. **Erro 406 (Not Acceptable)**: As políticas RLS do Supabase estavam muito restritivas
2. **Erro 403 (Forbidden)**: Falta de sincronização entre `auth.users` e tabela `users`
3. **Erro 400 (Bad Request)**: A tabela `user_progress` não tinha as colunas que o código JavaScript esperava
4. **"new row violates row-level security policy"**: Políticas RLS bloqueavam inserções

## ✅ SOLUÇÃO EM 2 PASSOS

### Passo 1: Executar Script MASTER no Supabase ⭐

1. Abra o **Supabase Dashboard**
2. Vá em **SQL Editor**
3. Cole e execute o arquivo: **`MASTER-FIX-COMPLETO.sql`**
4. Aguarde a mensagem de sucesso

Este script vai:
- ✅ Sincronizar `auth.users` com tabela `users`
- ✅ Adicionar todas as colunas faltantes em `user_progress`
- ✅ Corrigir as constraints da tabela
- ✅ Criar políticas RLS permissivas que funcionam
- ✅ Criar função de upsert otimizada
- ✅ Conceder todas as permissões necessárias

### Passo 2: Testar no Navegador

1. **Atualize a página** com `Ctrl+F5`
2. **Limpe o cache** (se necessário)
3. **Abra o Console** (`F12`)
4. **Tente ganhar XP** (assistir vídeo, completar aula)
5. **Verifique** - não devem mais aparecer erros 406/403/400

## 🔍 SCRIPTS DE DIAGNÓSTICO

Se ainda houver problemas, execute no Supabase:

### Diagnóstico Completo
```sql
-- Execute: diagnostico-user-progress.sql
```

### Verificar Políticas
```sql
SELECT policyname, cmd FROM pg_policies WHERE tablename = 'user_progress';
```

### Verificar Permissões
```sql
SELECT grantee, privilege_type 
FROM information_schema.role_table_grants
WHERE table_name = 'user_progress';
```

## 📝 O QUE FOI ALTERADO

### Tabela user_progress - ANTES:
```sql
- id
- user_id
- lesson_id
- completed
- progress_percentage
- last_accessed
- completed_at
```

### Tabela user_progress - DEPOIS:
```sql
- id
- user_id
- lesson_id (agora NULLABLE)
- completed
- progress_percentage
- last_accessed
- completed_at
+ completed_lessons (INTEGER[])
+ study_time_minutes (INTEGER)
+ study_streak (INTEGER)
+ last_study_date (TIMESTAMP)
+ achievements (TEXT[])
+ instrument_progress (JSONB)
+ created_at (TIMESTAMP)
```

### Políticas RLS - ANTES:
- ❌ Usavam `current_setting('request.jwt.claims')` - causava erro 406
- ❌ Muito complexas e falhavam em alguns casos

### Políticas RLS - DEPOIS:
- ✅ Usam `auth.jwt()->>'email'` - funciona corretamente
- ✅ Simplificadas e otimizadas
- ✅ 4 políticas: SELECT, INSERT, UPDATE, DELETE

## 🎯 RESULTADO ESPERADO

Após a correção:
- ✅ XP atualiza em tempo real
- ✅ Progresso sincroniza com Supabase
- ✅ Sem erros 406/400 no console
- ✅ Ranking funciona perfeitamente

## ❓ PROBLEMAS PERSISTENTES?

Se ainda houver erros, envie:
1. Screenshot do console após executar o script
2. Resultado do `diagnostico-user-progress.sql`
3. Email do usuário logado
