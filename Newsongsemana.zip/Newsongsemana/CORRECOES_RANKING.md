# 🔧 CORREÇÕES DO SISTEMA DE RANKING

## Data: 15/01/2026

## 🐛 Problemas Identificados

### 1. **Erro de Referência ao Cliente Supabase**
- **Sintoma**: URLs malformadas (wbzaktica@mctocgitfj)
- **Causa**: `ranking-system.js` usava `supabase` como variável global, mas ela não estava definida
- **Status HTTP**: 404 e 400

### 2. **Ordem de Carregamento dos Scripts**
- **Sintoma**: Scripts tentavam usar Supabase antes dele ser carregado
- **Causa**: `ranking-system.js` era carregado antes de `supabase-config.js`

### 3. **Usuário Não Autenticado**
- **Sintoma**: "Usuário não autenticado para buscar ranking"
- **Causa**: Lógica não tratava adequadamente casos de usuário não autenticado para ranking público

## ✅ Correções Aplicadas

### 1. Correção do `ranking-system.js`
**Arquivo**: `public/js/ranking-system.js`

**Mudança**: Adicionado obtenção explícita do cliente Supabase em todas as funções:

```javascript
// Antes (ERRADO):
let { data, error } = await supabase
  .from('ranking_by_xp')
  .select('*')

// Depois (CORRETO):
const supabase = window.SupabaseAPI?.getClient();
if (!supabase) {
  console.error('❌ Cliente Supabase não disponível');
  return [];
}

let { data, error } = await supabase
  .from('ranking_by_xp')
  .select('*')
```

**Funções Corrigidas**:
- `getRankingByXP()`
- `getRankingByStreak()`
- `getCurrentUserRanking()`

**Arquivo**: `public/js/xp-system.js`

Todas as funções que usavam `supabase` diretamente foram corrigidas:
- `addXP()`
- `updateStreak()`
- `getUserXP()`
- `getUserRanking()`

### 2. Correção do `supabase-config.js`
**Arquivo**: `public/js/supabase-config.js`

**Mudança**: Adicionada variável global `supabase` para compatibilidade:

```javascript
// Exportar cliente como variável global para compatibilidade
Object.defineProperty(window, 'supabase', {
  get: function() {
    return window.SupabaseAPI.getClient();
  }
});

// Também criar alias direto
window.supabaseClient = null;
setTimeout(() => {
  window.supabaseClient = window.SupabaseAPI.getClient();
}, 1000);
```

### 3. Reordenação de Scripts no `app.html`
**Arquivo**: `public/app.html`

**Mudança**: Movida carga do Supabase para ANTES de todos os outros scripts:

```html
<!-- ANTES -->
<script src="js/version-check.js?v=1.0.0"></script>
<script src="js/ranking-system.js?v=1.0.0"></script>
...
<script src="js/supabase.js"></script>
<script src="js/supabase-config.js?v=1.0.1"></script>

<!-- DEPOIS -->
<!-- Supabase Library - DEVE SER CARREGADO PRIMEIRO -->
<script src="js/supabase.js"></script>
<script src="js/supabase-config.js?v=1.0.2"></script>

<script src="js/version-check.js?v=1.0.0"></script>
<script src="js/ranking-system.js?v=1.0.0"></script>
```

### 4. Melhor Tratamento de Autenticação
**Arquivo**: `public/app.html`

**Mudança**: Adicionada verificação de sessão antes de buscar dados do usuário:

```javascript
// Verificar se o usuário está autenticado antes de buscar dados pessoais
const supabase = window.SupabaseAPI?.getClient();
if (!supabase) {
  console.warn('⚠️ Cliente Supabase não disponível');
} else {
  const { data: { session } } = await supabase.auth.getSession();
  
  if (session && session.user) {
    // Buscar dados do usuário autenticado
    const userXP = await XPSystem.getUserXP();
    const userRanking = await RankingSystem.getCurrentUserRanking();
    // ...
  } else {
    console.log('ℹ️ Usuário não autenticado - mostrando apenas ranking público');
  }
}
```

## 🧪 Como Testar

### Opção 1: Página de Debug
Criado arquivo: `public/test-ranking-debug.html`

Abra este arquivo no navegador para testar:
1. Carregamento do Supabase
2. Autenticação
3. Ranking por XP
4. Ranking por Streak
5. Tabela user_xp
6. Posição do usuário

### Opção 2: Console do Navegador
1. Abra `app.html` no navegador
2. Abra o Console (F12)
3. Navegue até a aba "Ranking"
4. Observe os logs:
   - ✅ "Cliente Supabase criado com sucesso!"
   - ✅ "Ranking por XP carregado: X usuários"
   - ✅ "Rankings carregados: Array(X)"

### Opção 3: Testes Manuais
Execute no console:

```javascript
// Testar cliente
window.SupabaseAPI.getClient()

// Testar ranking
await RankingSystem.getRankingByXP(10)

// Testar autenticação
await window.supabase.auth.getSession()
```

## 📋 Checklist de Verificação

- [ ] Nenhum erro 404 de recursos no console
- [ ] Nenhum erro "supabase is not defined"
- [ ] URLs corretas nas requisições (https://wbzaktlcxgmctocgtifj.supabase.co/...)
- [ ] Ranking carrega mesmo sem usuário autenticado
- [ ] Card do usuário aparece quando autenticado
- [ ] Logs aparecem na ordem correta:
  1. "Cliente Supabase criado"
  2. "Buscando ranking por XP"
  3. "Ranking carregado"

## 🔍 Diagnóstico de Problemas Persistentes

Se ainda houver erros:

### 1. Verificar se as Views Existem no Supabase
Execute no SQL Editor do Supabase:

```sql
-- Verificar views
SELECT table_name 
FROM information_schema.views 
WHERE table_schema = 'public' 
AND table_name LIKE 'ranking%';

-- Verificar tabela user_xp
SELECT COUNT(*) FROM user_xp;
```

### 2. Verificar Permissões RLS
Execute no SQL Editor:

```sql
-- Ver políticas RLS
SELECT * FROM pg_policies 
WHERE tablename IN ('user_xp', 'users');
```

### 3. Criar Views Manualmente
Se as views não existirem, execute:

```sql
-- Ver arquivo: database/10-create-ranking-views.sql
```

## 🚀 Próximos Passos

1. **Testar no navegador**: Abra `app.html` e vá para a aba Ranking
2. **Verificar logs**: Não deve haver erros no console
3. **Autenticar**: Faça login e verifique se seu card aparece
4. **Popular dados**: Use o arquivo `database/08-populate-existing-users-xp.sql` se necessário

## 📝 Notas Técnicas

### Por que o erro de URL malformada?
Quando `supabase` estava `undefined`, o JavaScript tentava acessar `.from()` em `undefined`, causando erro. O navegador então tentava fazer uma requisição HTTP para uma URL construída incorretamente.

### Por que a ordem dos scripts importa?
JavaScript é executado na ordem em que aparece no HTML. Se `ranking-system.js` executa antes de `supabase-config.js` carregar, a variável `window.SupabaseAPI` ainda não existe.

### Por que usar `Object.defineProperty`?
Isso cria uma propriedade "getter" que sempre retorna o cliente atual, mesmo que ele seja inicializado depois.

## 🎯 Resultado Esperado

Após as correções:
- ✅ Ranking carrega sem erros
- ✅ URLs corretas nas requisições
- ✅ Funciona com ou sem autenticação
- ✅ Logs informativos no console
- ✅ Performance melhorada
