# 🚨 SOLUÇÃO RÁPIDA: Conta não vai para o banco

## ❌ Problema
Você cria uma conta mas ela NÃO aparece no banco de dados.

## 🔍 Causa
**Políticas RLS (Row Level Security)** estão bloqueando a inserção de novos usuários na tabela `users`.

## ✅ SOLUÇÃO EM 3 PASSOS

### 1️⃣ Execute o SQL de Correção
1. Abra o Supabase Dashboard: https://supabase.com/dashboard
2. Vá em **SQL Editor**
3. Cole TODO o conteúdo do arquivo: **`database/FIX-RLS-PERMITIR-REGISTRO.sql`**
4. Clique em **RUN** ▶️

### 2️⃣ Verifique o Diagnóstico
1. Abra: **`public/supabase-admin.html`**
2. Clique no botão **"🔍 Diagnosticar Registro"**
3. Deve aparecer **"✅ Tudo Funcionando!"**

### 3️⃣ Teste Criando uma Conta
1. Abra: **`public/register.html`**
2. Crie uma nova conta
3. Abra o **Console do navegador** (F12)
4. Deve ver mensagens:
   ```
   ✅ Registro no Supabase AUTH bem-sucedido!
   ✅ Usuário inserido na tabela users com sucesso!
   ```
5. Abra: **`public/supabase-admin.html`**
6. **A conta deve aparecer na lista!** 🎉

## 🔧 O Que o SQL Faz

```sql
-- Permite criar contas (INSERT)
CREATE POLICY "Allow insert users" ON users FOR INSERT WITH CHECK (true);

-- Permite ver usuários (SELECT)  
CREATE POLICY "Allow select users" ON users FOR SELECT USING (true);

-- Permite atualizar próprios dados (UPDATE)
CREATE POLICY "Allow update own user" ON users FOR UPDATE 
USING (auth.uid() = id);
```

## 📊 Verificar pelo Console

Abra o Console (F12) e digite:

```javascript
// Ver diagnóstico completo
await SupabaseAdmin.info()

// Testar inserção
const testId = crypto.randomUUID();
const { data, error } = await supabase
  .from('users')
  .insert([{
    id: testId,
    email: 'teste@gmail.com',
    name: 'Teste',
    role: 'student',
    is_active: true
  }])
  .select();

console.log('Resultado:', data, error);

// Se funcionou, deletar teste
if (!error) {
  await supabase.from('users').delete().eq('id', testId);
  console.log('✅ INSERT funciona! Teste deletado.');
}
```

## ⚠️ Se Ainda Não Funcionar

### Erro: "relation users does not exist"
**Solução:** Execute: `database/01-complete-schema.sql`

### Erro: "permission denied"
**Solução:** Execute: `database/FIX-RLS-PERMITIR-REGISTRO.sql`

### Erro no Console: "Failed to insert"
**Solução:** 
1. Verifique se executou o SQL
2. Recarregue a página
3. Tente novamente

## 🎯 Checklist

- [ ] Executei `FIX-RLS-PERMITIR-REGISTRO.sql` no Supabase
- [ ] Cliquei em "🔍 Diagnosticar Registro" e apareceu ✅
- [ ] Abri o Console (F12) ao criar conta
- [ ] Vi mensagem "✅ Usuário inserido na tabela users"
- [ ] A conta aparece em supabase-admin.html

## 📝 Arquivos Importantes

- **`database/FIX-RLS-PERMITIR-REGISTRO.sql`** ⭐ Execute este!
- **`public/supabase-admin.html`** - Botão de diagnóstico
- **`public/js/auth.js`** - Código de registro (já corrigido)

## 💡 Por Que Isso Acontece?

1. **RLS (Row Level Security)** protege os dados
2. Por padrão, **NINGUÉM** pode inserir na tabela
3. Precisa criar **políticas** que permitam INSERT
4. O SQL cria essas políticas automaticamente

## 🚀 Depois de Corrigir

Todas as novas contas:
- ✅ Serão criadas no Supabase Auth
- ✅ Serão inseridas na tabela users
- ✅ Aparecerão no painel admin
- ✅ Funcionarão perfeitamente

**Execute o SQL agora e teste! 🎉**
