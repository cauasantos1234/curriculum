# 🔐 Painel Admin Supabase - Guia Completo

## 🎯 Funcionalidades Implementadas

### 📡 Status da Conexão
- ✅ Verifica se a biblioteca Supabase está carregada
- ✅ Confirma se o cliente está inicializado
- ✅ Mostra a URL do projeto Supabase

### 👤 Sessão Atual
- ✅ Mostra informações do usuário logado
- ✅ Exibe email, ID, último login, data de criação
- ✅ Botão para atualizar sessão
- ✅ Botão para fazer logout

### 📋 Gestão de Usuários
- ✅ **Atualizar Lista**: Recarrega usuários da tabela `users`
- ✅ **Ver Todos os Usuários**: Mostra usuários cadastrados
- ✅ **Ver Usuários de Auth**: Busca TODOS os usuários (incluindo não-logados)
- ✅ **Criar Usuário**: Cria novo usuário diretamente no painel
- ✅ **Sincronizar Auth→Users**: Sincroniza contas do auth.users para tabela users

### 📊 Estatísticas
- ✅ Total de usuários cadastrados
- ✅ Total de vídeos no sistema
- ✅ XP total acumulado
- ✅ Registros de progresso
- ✅ Atualização em tempo real

### ⚡ Comandos Rápidos
- ✅ **Testar Conexão**: Verifica se o Supabase está respondendo
- ✅ **Ver Tokens**: Exibe access_token e refresh_token
- ✅ **Verificar RLS**: Testa políticas de segurança nas tabelas
- ✅ **Limpar Cache**: Remove dados do localStorage/sessionStorage
- ✅ **Exportar Dados**: Baixa configurações e dados locais em JSON
- ✅ **Ver Tabelas**: Lista todas as tabelas e contagem de registros
- ✅ **Saúde do BD**: Diagnóstico completo do banco de dados

## 🚀 Como Usar

### 1. Acessar o Painel
Abra o arquivo no navegador:
```
http://localhost:5500/supabase-admin.html
```
ou através do Live Server do VS Code

### 2. Criar Novo Usuário
1. Clique em **"➕ Criar Usuário"**
2. Preencha:
   - Email
   - Senha (mínimo 6 caracteres)
   - Nome (opcional)
   - Role (Aluno/Professor/Admin)
3. Clique em **"✅ Criar"**
4. O usuário será criado no Supabase Auth

### 3. Ver TODOS os Usuários (Incluindo Não-Logados)
**Opção A - Dashboard (Recomendado):**
1. Clique em **"🔍 Ver Usuários de Auth"**
2. Siga as instruções para acessar o Dashboard do Supabase
3. Vá em Authentication → Users

**Opção B - Criar Função SQL:**
1. Clique em **"🔍 Ver Usuários de Auth"**
2. Copie o SQL fornecido
3. Execute no SQL Editor do Supabase
4. Clique novamente em **"🔍 Ver Usuários de Auth"**
5. Agora verá todos os usuários diretamente no painel!

### 4. Sincronizar Usuários
Se criou contas que não aparecem na tabela `users`:
1. Execute o SQL do arquivo `database/sync-auth-to-users.sql`
2. Clique em **"🔄 Sincronizar Auth→Users"**
3. Todos os usuários do auth serão copiados para a tabela users

### 5. Ver Estatísticas
As estatísticas carregam automaticamente ao abrir o painel:
- Total de usuários
- Total de vídeos
- XP acumulado
- Registros de progresso

Clique em **"🔄 Atualizar Estatísticas"** para recarregar.

### 6. Verificar Saúde do Sistema
1. Clique em **"🏥 Saúde do BD"**
2. O painel executará 5 testes:
   - Conexão com Supabase
   - Sistema de Autenticação
   - Tabela users
   - Tabela videos
   - Políticas RLS
3. Mostra porcentagem de saúde geral

### 7. Limpar Cache
Se tiver problemas de sessão ou dados desatualizados:
1. Clique em **"🗑️ Limpar Cache"**
2. Confirme a ação
3. Recarregue a página

## 📁 Arquivos SQL Auxiliares

### 1. `create-get-all-users-function.sql`
Cria função para buscar todos os usuários do auth.users
- Permite ver contas criadas mas não-logadas
- Mostra status de confirmação de email
- Exibe último login

### 2. `sync-auth-to-users.sql`
Sincroniza auth.users → users
- Copia todos os usuários do auth para tabela customizada
- Atualiza dados existentes
- Preserva informações atuais

## 🔧 Troubleshooting

### Problema: Usuários não aparecem
**Solução:**
1. Verifique se executou o SQL de criação da tabela users
2. Execute `sync-auth-to-users.sql`
3. Clique em "🔄 Sincronizar Auth→Users"

### Problema: Erro "RLS bloqueando acesso"
**Solução:**
Execute no SQL Editor:
```sql
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow read users" ON users FOR SELECT USING (true);
```

### Problema: Não consigo criar usuários
**Solução:**
1. Verifique se está logado com uma conta
2. Confirme que o Supabase está configurado corretamente
3. Verifique o console do navegador (F12) para erros

### Problema: Estatísticas não carregam
**Solução:**
1. Verifique se as tabelas existem no banco
2. Execute os scripts SQL da pasta `database/`
3. Verifique políticas RLS com botão "🔒 Verificar RLS"

## 📊 Recursos do Painel

### Design
- ✅ Interface moderna e responsiva
- ✅ Tema escuro profissional
- ✅ Ícones e cores intuitivas
- ✅ Mensagens de status claras

### Segurança
- ✅ Valida conexões antes de executar
- ✅ Confirmações para ações destrutivas
- ✅ Exibe erros detalhados para debug
- ✅ Não expõe dados sensíveis

### Performance
- ✅ Carregamento assíncrono
- ✅ Consultas otimizadas
- ✅ Cache de dados quando apropriado
- ✅ Feedback visual em todas as ações

## 🎓 Próximos Passos

1. **Execute os SQLs necessários** (pasta `database/`)
2. **Crie alguns usuários** de teste
3. **Sincronize** auth → users
4. **Verifique a saúde** do sistema
5. **Explore todas as funcionalidades**

## 📝 Notas Importantes

- Este painel é para **administração** apenas
- Não exponha em produção sem autenticação adicional
- Use com a conta de administrador
- Faça backup antes de executar SQLs no banco

## 🆘 Suporte

Se encontrar problemas:
1. Verifique o console do navegador (F12)
2. Clique em "🏥 Saúde do BD" para diagnóstico
3. Verifique se todos os SQLs foram executados
4. Confirme configuração do Supabase em `js/supabase-config.js`
