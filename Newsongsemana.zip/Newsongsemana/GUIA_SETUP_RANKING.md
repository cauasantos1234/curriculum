# 🏆 Guia de Configuração do Sistema de Ranking

## 📋 O que foi criado

### 1. Script SQL de Setup Completo
**Arquivo:** `database/setup-ranking-completo.sql`

Este script cria toda a estrutura necessária para o sistema de ranking:
- ✅ Tabelas `user_xp` e `xp_transactions`
- ✅ Funções SQL (`calculate_level`, `add_xp_to_user`, `get_user_ranking`)
- ✅ Views de ranking (`ranking_by_xp`, `ranking_by_streak`)
- ✅ Permissões de acesso
- ✅ População automática de dados para usuários existentes

### 2. Página de Visualização do Ranking
**Arquivo:** `public/ranking.html`

Interface completa para visualizar os rankings com:
- 🏆 Ranking por XP Total
- 🔥 Ranking por Streak (dias consecutivos)
- 📊 Estatísticas gerais
- 💎 Design moderno e responsivo

## 🚀 Como Configurar (Passo a Passo)

### PASSO 1: Executar o Script SQL no Supabase

1. **Acesse o Supabase Dashboard:**
   - Abra: https://app.supabase.com
   - Faça login na sua conta
   - Selecione seu projeto

2. **Abra o SQL Editor:**
   - No menu lateral esquerdo, clique em **"SQL Editor"**
   - Clique no botão **"New query"** (Nova consulta)

3. **Execute o Script:**
   - Abra o arquivo `database/setup-ranking-completo.sql` no VS Code
   - Copie TODO o conteúdo do arquivo (Ctrl+A, Ctrl+C)
   - Cole no SQL Editor do Supabase
   - Clique no botão **"Run"** (ou pressione Ctrl+Enter)

4. **Verifique os Resultados:**
   Você verá mensagens como:
   ```
   ✅ SETUP DO RANKING CONCLUÍDO!
   ========================================
   Total de usuários com XP: X
   Ranking por XP: X usuários
   Ranking por Streak: Y usuários
   ========================================
   ```

   E também verá o Top 10 de cada ranking!

### PASSO 2: Testar o Ranking

#### Opção A: Usar a página dedicada de ranking

1. **Abra a página de ranking:**
   - Navegue até `public/ranking.html` no navegador
   - Ou clique com o botão direito no arquivo e escolha "Open with Live Server"

2. **Você verá:**
   - Total de usuários cadastrados
   - XP total distribuído
   - Maior streak
   - Rankings por XP e Streak

#### Opção B: Ver no app principal

1. **Abra o app:**
   - Navegue até `public/app.html` no navegador
   - Faça login com um usuário
   - Role a página até a seção "🏆 Ranking dos Melhores"

## 🧪 Como Testar Funcionalidades

### 1. Verificar Views no Supabase

Execute no SQL Editor:

```sql
-- Ver ranking por XP
SELECT * FROM ranking_by_xp LIMIT 10;

-- Ver ranking por Streak
SELECT * FROM ranking_by_streak LIMIT 10;

-- Ver todos os usuários com XP
SELECT * FROM user_xp ORDER BY total_xp DESC;
```

### 2. Testar Função de Adicionar XP

Execute no SQL Editor (substitua o USER_ID pelo ID de um usuário real):

```sql
-- Adicionar 50 XP a um usuário
SELECT add_xp_to_user(
  'USER_ID_AQUI'::uuid,
  50,
  'test_action',
  NULL,
  'Teste de XP'
);
```

### 3. Testar Ranking de um Usuário Específico

Execute no SQL Editor (substitua o USER_ID):

```sql
-- Ver posição do usuário nos rankings
SELECT get_user_ranking('USER_ID_AQUI'::uuid);
```

## 📊 Sistema de XP - Como Funciona

### Ganho de XP por Ações

| Ação | XP Ganho |
|------|----------|
| Assistir 25% do vídeo | 5 XP |
| Assistir 50% do vídeo | 10 XP |
| Assistir 75% do vídeo | 15 XP |
| Assistir 100% do vídeo | 25 XP |
| Completar aula | 50 XP |
| Completar módulo | 200 XP |
| Salvar vídeo | 2 XP |
| Avaliar professor | 5 XP |
| Bônus diário | 10 XP |

### Níveis

| Nível | XP Necessário |
|-------|---------------|
| Nível 1 (Iniciante) | 0-100 XP |
| Nível 2 (Aprendiz) | 101-300 XP |
| Nível 3 (Estudante) | 301-600 XP |
| Nível 4 (Dedicado) | 601-1000 XP |
| Nível 5 (Expert) | 1001-1500 XP |
| Nível 6+ (Mestre) | +500 XP por nível |

### Bônus de Streak (Dias Consecutivos)

| Streak | Bônus |
|--------|-------|
| 3 dias | +20 XP |
| 7 dias | +50 XP |
| 30 dias | +200 XP |
| 100 dias | +1000 XP |

## 🔧 Integração com o Código JavaScript

### Adicionar XP via JavaScript

```javascript
// Exemplo de como adicionar XP a um usuário
async function addXPToUser(userId, amount, action) {
  const { data, error } = await supabase.rpc('add_xp_to_user', {
    p_user_id: userId,
    p_xp_amount: amount,
    p_action_type: action,
    p_description: 'Descrição da ação'
  });
  
  if (data && data.level_up) {
    console.log('🎉 Subiu de nível!');
  }
}
```

### Buscar Ranking

```javascript
// Buscar ranking por XP
const { data: rankingXP } = await supabase
  .from('ranking_by_xp')
  .select('*')
  .limit(10);

// Buscar ranking por Streak
const { data: rankingStreak } = await supabase
  .from('ranking_by_streak')
  .select('*')
  .limit(10);

// Buscar posição do usuário
const { data: userRank } = await supabase.rpc('get_user_ranking', {
  p_user_id: userId
});
```

## ✅ Checklist de Verificação

- [ ] Script SQL executado com sucesso no Supabase
- [ ] Mensagem de conclusão apareceu com contagem de usuários
- [ ] Top 10 dos rankings foi exibido
- [ ] Página `ranking.html` abre sem erros
- [ ] Rankings aparecem com dados dos usuários
- [ ] Estatísticas mostram valores corretos
- [ ] Console do navegador não mostra erros (F12)

## 🐛 Problemas Comuns

### Erro: "relation user_xp does not exist"
**Solução:** O script não foi executado. Execute `setup-ranking-completo.sql`

### Erro: "function calculate_level does not exist"
**Solução:** Execute todo o script `setup-ranking-completo.sql` novamente

### Rankings aparecem vazios
**Solução:** 
1. Verifique se há usuários em `auth.users`
2. Execute o script novamente - ele popula dados automaticamente

### Erro de permissão ao acessar views
**Solução:** O script já inclui permissões, mas se necessário, execute:
```sql
GRANT SELECT ON ranking_by_xp TO anon, authenticated;
GRANT SELECT ON ranking_by_streak TO anon, authenticated;
```

## 📝 Próximos Passos

1. ✅ Sistema de ranking configurado
2. ⏭️ Integrar ganho de XP nas ações dos usuários
3. ⏭️ Adicionar notificações de subida de nível
4. ⏭️ Criar emblemas e conquistas
5. ⏭️ Sistema de recompensas

## 💡 Dicas

- Os dados são populados automaticamente com valores aleatórios
- Você pode resetar os dados executando o script novamente
- Use a página `ranking.html` para visualização rápida
- O ranking é atualizado em tempo real quando há mudanças
- Todos os cálculos são feitos no banco de dados para melhor performance

---

**Documentação criada em:** 20 de Janeiro de 2026
**Sistema:** NewSong - Plataforma de Ensino Musical
